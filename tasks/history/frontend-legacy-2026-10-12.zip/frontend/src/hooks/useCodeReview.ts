import { useState, useCallback, useEffect, useRef, MutableRefObject } from 'react'
import {
  fetchFileContent,
  subscribeToReviewStream,
} from '../services/api'
import { FileNode } from '../components/FileExplorer'
import { AgentId, Finding, Severity } from '../components/AgentPanel'
import { AgentStepUpdate, CodeIssue, ReviewOutcome, ReviewReport } from '../types'
import { findingRange, resolveSourceFile } from '../review/source'
import type { SourceRange } from '../components/CodeEditor'

// Helper: Extract file extension from filename
function extOf(name: string): string | undefined {
  const parts = name.split('.')
  return parts.length > 1 ? parts[parts.length - 1].toLowerCase() : undefined
}

const REVIEWABLE_EXTENSIONS = new Set([
  'py', 'js', 'ts', 'tsx', 'jsx', 'java', 'go', 'rs', 'c', 'cpp', 'h',
  'html', 'css', 'md', 'json', 'yaml', 'yml',
])
const IGNORED_FOLDERS = new Set([
  '.git', '.devwatch', '__pycache__', '.venv', 'venv', 'node_modules',
  '.idea', '.vscode', 'dist', 'build', '.next', 'coverage',
])
const IGNORED_FILE_NAMES = new Set(['package-lock.json', 'yarn.lock', 'pnpm-lock.yaml'])

function canReviewFolderFile(pathParts: string[]): boolean {
  const fileName = pathParts[pathParts.length - 1]?.toLowerCase() || ''
  const directories = pathParts.slice(0, -1).map((part) => part.toLowerCase())
  if (pathParts.some((part) => !part || part === '..')) return false
  if (directories.some((part) => part.startsWith('.') || IGNORED_FOLDERS.has(part))) return false
  if (fileName.startsWith('.') || IGNORED_FILE_NAMES.has(fileName)) return false
  if (/\.(?:min\.js|min\.css|map|lock)$/.test(fileName)) return false
  return REVIEWABLE_EXTENSIONS.has(extOf(fileName) || '')
}

/**
 * Build FileNode tree from Web API FileList (webkitdirectory native folder upload).
 * Handles Windows backslashes, creates folder hierarchy, and reads file content.
 */
export async function buildTreeFromFileList(files: FileList): Promise<{ tree: FileNode[]; name: string; reviewableCount: number; omittedCount: number }> {
  const fileArray = Array.from(files)
  if (fileArray.length === 0) throw new Error('No readable source files were selected.')
  let reviewableCount = 0
  let omittedCount = 0

  // Get project name from webkitRelativePath or first file name (normalizing Windows backslashes)
  const samplePath = ((fileArray[0] as any).webkitRelativePath || fileArray[0].name).replace(/\\/g, '/')
  const pathParts = samplePath.split('/')
  const rootName = pathParts.length > 1 ? pathParts[0] : 'workspace'

  const rootNodes: FileNode[] = []
  const folderMap = new Map<string, FileNode>()

  // Helper to ensure a folder node exists in folderMap and parent folder
  const getOrCreateFolder = (folderPath: string, folderName: string): FileNode => {
    if (folderMap.has(folderPath)) {
      return folderMap.get(folderPath)!
    }
    const folderNode: FileNode = {
      id: folderPath,
      name: folderName,
      type: 'folder',
      children: [],
    }
    folderMap.set(folderPath, folderNode)

    const lastSlash = folderPath.lastIndexOf('/')
    if (lastSlash !== -1) {
      const parentPath = folderPath.slice(0, lastSlash)
      const parentName = parentPath.slice(parentPath.lastIndexOf('/') + 1)
      const parentNode = getOrCreateFolder(parentPath, parentName)
      if (!parentNode.children!.some((c) => c.id === folderPath)) {
        parentNode.children!.push(folderNode)
      }
    } else {
      if (!rootNodes.some((c) => c.id === folderPath)) {
        rootNodes.push(folderNode)
      }
    }

    return folderNode
  }

  // Sort files for consistent tree order
  fileArray.sort((a, b) => {
    const pa = ((a as any).webkitRelativePath || a.name).replace(/\\/g, '/')
    const pb = ((b as any).webkitRelativePath || b.name).replace(/\\/g, '/')
    return pa.localeCompare(pb)
  })

  for (const file of fileArray) {
    const rawRel = ((file as any).webkitRelativePath || file.name).replace(/\\/g, '/')
    const parts = rawRel.split('/')
    // If path has root folder prefix (e.g. "myfolder/src/index.js"), strip "myfolder"
    const relParts = parts.length > 1 ? parts.slice(1) : parts

    const fileName = relParts[relParts.length - 1]
    const ext = extOf(fileName)
    const fileId = relParts.join('/')
    if (!canReviewFolderFile(relParts)) {
      omittedCount += 1
      continue
    }

    let content: string | undefined
    let unavailableReason: string | undefined
    if (file.size < 2_000_000) {
      try {
        const read = await file.text()
        if (!read.trim()) unavailableReason = 'This file is empty and was omitted from the review.'
        else if (read.includes('\0')) unavailableReason = 'This file appears to be binary and was omitted from the review.'
        else content = read
      } catch {
        unavailableReason = 'The browser could not read this file from the selected folder.'
      }
    } else {
      unavailableReason = 'This file exceeds the 2 MB upload limit and was omitted from the review.'
    }
    if (content === undefined) omittedCount += 1
    else reviewableCount += 1

    const fileNode: FileNode = {
      id: fileId,
      name: fileName,
      type: 'file',
      ext,
      content,
      unavailableReason,
    }

    if (relParts.length === 1) {
      rootNodes.push(fileNode)
    } else {
      const folderParts = relParts.slice(0, -1)
      const folderPath = folderParts.join('/')
      const folderName = folderParts[folderParts.length - 1]
      const parentFolder = getOrCreateFolder(folderPath, folderName)
      parentFolder.children!.push(fileNode)
    }
  }

  // Sort top-level entries: folders first, then files alphabetically
  rootNodes.sort((a, b) => {
    const af = a.type === 'folder' ? 0 : 1
    const bf = b.type === 'folder' ? 0 : 1
    return af - bf || a.name.localeCompare(b.name)
  })

  if (reviewableCount === 0) throw new Error('No readable source files were selected. Choose a folder with text source files under 2 MB.')
  return { tree: rootNodes, name: rootName, reviewableCount, omittedCount }
}

/**
 * Map DevWatch backend CodeIssue array to frontend Finding array.
 * Handles categorization, severity mapping, and finding ID generation.
 */
export function mapIssuesToFindings(issues: CodeIssue[]): Finding[] {
  return issues.map((iss, index) => {
    let agent: AgentId = 'quality'
    if (iss.category.toLowerCase().includes('security') || iss.severity === 'CRITICAL' || iss.severity === 'HIGH') {
      agent = 'security'
    } else if (iss.category.toLowerCase().includes('quality') || iss.category.toLowerCase().includes('refactor')) {
      agent = 'quality'
    } else {
      agent = 'bugs'
    }

    let sev: Severity = 'low'
    if (iss.severity === 'CRITICAL') sev = 'critical'
    else if (iss.severity === 'HIGH') sev = 'high'
    else if (iss.severity === 'MEDIUM') sev = 'medium'
    else if (iss.severity === 'INFO') sev = 'info'

    const fileName = iss.file_path.split('/').pop() || iss.file_path
    const line = iss.start_line ?? iss.line_number ?? null

    return {
      id: iss.finding_id || `finding-${index}-${iss.file_path}-${line ?? 'unknown'}`,
      agent,
      severity: sev,
      title: iss.title,
      description: iss.description,
      fileId: iss.file_path,
      fileName,
      line,
      startLine: iss.start_line,
      endLine: iss.end_line,
      suggestion: iss.suggestion,
      replacement_code: iss.replacement_code,
      finding_id: iss.finding_id,
      verification_status: iss.verification_status,
      cwe_id: iss.cwe_id,
      confidence_score: iss.confidence_score,
      verificationRationale: iss.verification_rationale,
      verificationConfidence: iss.verification_confidence,
      evidence: iss.evidence,
      codeSnippet: iss.code_snippet,
    }
  })
}

export function mapReviewReport(report: ReviewReport) {
  const findings = mapIssuesToFindings(report.issues || [])
  const manualReviewCandidates = mapIssuesToFindings(report.manual_review_candidates || [])
  let outcome: ReviewOutcome = 'no-findings'
  if (findings.length > 0) outcome = 'findings'
  else if (manualReviewCandidates.length > 0) outcome = 'manual-only'
  else if (/No reviewable Git changes were found/i.test(report.summary || '')) outcome = 'clean-git'
  else if (/Empty repository: no reviewable source files/i.test(report.summary || '')) outcome = 'empty-source'
  return {
    findings,
    manualReviewCandidates,
    summary: report.summary || '',
    metrics: report.metrics || {},
    outcome,
    partial: report.metrics?.partial === true,
  }
}

export function appendProgressStep(
  steps: AgentStepUpdate[],
  step: AgentStepUpdate
): AgentStepUpdate[] {
  return [...steps, step].slice(-100)
}

export class ReviewRunController {
  private generation = 0
  private request: AbortController | null = null

  start() {
    this.invalidate()
    const generation = this.generation
    this.request = new AbortController()
    return {
      signal: this.request.signal,
      isCurrent: () => this.generation === generation,
    }
  }

  invalidate() {
    this.generation += 1
    this.request?.abort()
    this.request = null
  }
}

/**
 * useCodeReview — custom hook encapsulating code review state and business logic.
 *
 * Manages:
 * - File tree state (project files and folder structure)
 * - Analysis state (running, complete, findings)
 * - UI state (selected file, open files, highlight line, active agent)
 *
 * Exposes methods:
 * - handleSelectFile, handleCloseFile
 * - handleRunAnalysis (with WebSocket subscription)
 * - handleFindingClick (navigate to finding location)
 * - handleOpenFolder, handleFolderInputChange (load folders from user's device)
 *
 * Design principle: All review-related state and logic is in one place.
 * Components only render; they call hook methods when user interacts.
 */
export function useCodeReview() {
  const [targetPath, setTargetPath] = useState('')
  const [sourceMode, setSourceMode] = useState<'server' | 'upload' | null>(null)
  const [projectName, setProjectName] = useState('workspace')
  const [tree, setTree] = useState<FileNode[]>([])
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null)
  const [openFiles, setOpenFiles] = useState<FileNode[]>([])
  const [activeAgent, setActiveAgent] = useState<AgentId>('security')
  const [analysisRunning, setAnalysisRunning] = useState(false)
  const [analysisComplete, setAnalysisComplete] = useState(false)
  const [highlightRange, setHighlightRange] = useState<SourceRange | null>(null)
  const [findings, setFindings] = useState<Finding[]>([])
  const [report, setReport] = useState<ReviewReport | null>(null)
  const [reportId, setReportId] = useState<string | null>(null)
  const [manualReviewCandidates, setManualReviewCandidates] = useState<Finding[]>([])
  const [progressSteps, setProgressSteps] = useState<AgentStepUpdate[]>([])
  const [reviewError, setReviewError] = useState<string | null>(null)
  const [partial, setPartial] = useState(false)
  const [folderLoading, setFolderLoading] = useState(false)
  const [sourceError, setSourceError] = useState<string | null>(null)
  const [uploadFileCount, setUploadFileCount] = useState(0)
  const [omittedFileCount, setOmittedFileCount] = useState(0)
  const [reviewCanceled, setReviewCanceled] = useState(false)

  const folderInputRef = useRef<HTMLInputElement>(null)
  const streamCleanupRef = useRef<(() => void) | null>(null)
  const reviewRunsRef = useRef(new ReviewRunController())
  const navigationRef = useRef(0)
  const canRunReview = !folderLoading && (sourceMode === 'server' ? Boolean(targetPath.trim()) : sourceMode === 'upload' && uploadFileCount > 0)

  useEffect(() => () => {
    navigationRef.current += 1
    reviewRunsRef.current.invalidate()
    streamCleanupRef.current?.()
  }, [])

  const applyReport = useCallback((completedReport: ReviewReport, completedReportId?: string) => {
    const view = mapReviewReport(completedReport)
    setReport(completedReport)
    setReportId(completedReportId || null)
    setFindings(view.findings)
    setManualReviewCandidates(view.manualReviewCandidates)
    setPartial(view.partial)
    setAnalysisComplete(true)
    setAnalysisRunning(false)
  }, [])

  const openSourceFile = useCallback(async (filePath: string, range: SourceRange | null) => {
    const navigation = ++navigationRef.current
    const fullFile = await resolveSourceFile(filePath, sourceMode, tree, targetPath, fetchFileContent)
    if (navigationRef.current !== navigation) return
    setSelectedFile(fullFile)
    setHighlightRange(range)
    setOpenFiles((prev) => prev.some((file) => file.id === fullFile.id)
      ? prev.map((file) => file.id === fullFile.id ? fullFile : file)
      : [...prev, fullFile])
  }, [sourceMode, tree, targetPath])

  const handleSelectFile = useCallback(async (file: FileNode) => {
    await openSourceFile(file.id, null)
  }, [openSourceFile])

  const handleCloseFile = useCallback(
    (fileId: string) => {
      navigationRef.current += 1
      setOpenFiles((prev) => {
        const next = prev.filter((f) => f.id !== fileId)
        if (selectedFile?.id === fileId) {
          setSelectedFile(next.length > 0 ? next[next.length - 1] : null)
        }
        return next
      })
      setHighlightRange(null)
    },
    [selectedFile]
  )

  const handleRunAnalysis = useCallback(async () => {
    if (analysisRunning || !canRunReview) return
    const run = reviewRunsRef.current.start()
    streamCleanupRef.current?.()
    streamCleanupRef.current = null
    setAnalysisComplete(false)
    setAnalysisRunning(true)
    setReport(null)
    setReportId(null)
    setFindings([])
    setManualReviewCandidates([])
    setProgressSteps([])
    setReviewError(null)
    setPartial(false)
    setReviewCanceled(false)

    const failReview = (error: Error) => {
      if (!run.isCurrent()) return
      setReport(null)
      setReportId(null)
      setProgressSteps((previous) => appendProgressStep(previous, {
        agent_name: sourceMode === 'upload' ? 'Upload request' : 'Connection',
        status: 'FAILED',
        message: error.message,
      }))
      setReviewError(error.message)
      setAnalysisRunning(false)
      setAnalysisComplete(false)
      streamCleanupRef.current?.()
      streamCleanupRef.current = null
    }

    try {
      const collectFiles = (nodes: FileNode[]): Array<{ file_path: string; content: string }> => {
        const collected: Array<{ file_path: string; content: string }> = []
        for (const node of nodes) {
          if (node.type === 'file' && node.content?.trim()) {
            collected.push({ file_path: node.id, content: node.content })
          } else if (node.type === 'folder' && node.children) {
            collected.push(...collectFiles(node.children))
          }
        }
        return collected
      }

      const uploadedFiles = collectFiles(tree)
      const streamSource = sourceMode === 'upload'
        ? { files: uploadedFiles }
        : { target_path: targetPath.trim() }
      streamCleanupRef.current = subscribeToReviewStream(
        streamSource,
        (step) => {
          if (run.isCurrent()) {
            setProgressSteps((previous) => appendProgressStep(previous, step))
          }
        },
        (data) => {
          if (!run.isCurrent()) return
          applyReport(data.report, data.report_id)
          streamCleanupRef.current?.()
          streamCleanupRef.current = null
        },
        failReview,
      )
    } catch (error) {
      failReview(error instanceof Error ? error : new Error('Review failed'))
    }
  }, [analysisRunning, canRunReview, sourceMode, tree, targetPath, applyReport])

  const handleFindingClick = useCallback(async (finding: Finding) => {
    await openSourceFile(finding.fileId, findingRange(finding))
  }, [openSourceFile])

  const handleChooseServer = useCallback(() => {
    navigationRef.current += 1
    reviewRunsRef.current.invalidate()
    streamCleanupRef.current?.()
    streamCleanupRef.current = null
    setSourceMode('server')
    setTree([])
    setProjectName('server repository')
    setSelectedFile(null)
    setOpenFiles([])
    setHighlightRange(null)
    setFolderLoading(false)
    setReport(null)
    setReportId(null)
    setFindings([])
    setManualReviewCandidates([])
    setProgressSteps([])
    setReviewError(null)
    setAnalysisRunning(false)
    setAnalysisComplete(false)
    setPartial(false)
    setReviewCanceled(false)
    setSourceError(null)
    setUploadFileCount(0)
    setOmittedFileCount(0)
  }, [])

  const handleServerPathChange = useCallback((path: string) => {
    navigationRef.current += 1
    setTargetPath(path)
    setSelectedFile(null)
    setOpenFiles([])
    setHighlightRange(null)
    setAnalysisComplete(false)
    setReport(null)
    setReportId(null)
    setFindings([])
    setManualReviewCandidates([])
    setProgressSteps([])
    setPartial(false)
    setSourceError(null)
    setReviewError(null)
    setReviewCanceled(false)
  }, [])

  const handleCancelReview = useCallback(() => {
    reviewRunsRef.current.invalidate()
    streamCleanupRef.current?.()
    streamCleanupRef.current = null
    setAnalysisRunning(false)
    setAnalysisComplete(false)
    setReviewCanceled(true)
    setReport(null)
    setReportId(null)
    setProgressSteps([])
  }, [])

  // Native OS file/folder picker trigger
  const handleOpenFolder = useCallback(() => {
    folderInputRef.current?.click()
  }, [])

  // Handle native folder selection from user's device
  const handleFolderInputChange = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files
      if (!files || files.length === 0) return
      navigationRef.current += 1
      const selection = reviewRunsRef.current.start()
      streamCleanupRef.current?.()
      streamCleanupRef.current = null
      setAnalysisRunning(false)
      setAnalysisComplete(false)
      setSourceMode(null)
      setProjectName('workspace')
      setTargetPath('')
      setTree([])
      setSelectedFile(null)
      setOpenFiles([])
      setHighlightRange(null)
      setUploadFileCount(0)
      setOmittedFileCount(0)
      setReport(null)
      setReportId(null)
      setFindings([])
      setManualReviewCandidates([])
      setProgressSteps([])
      setReviewError(null)
      setPartial(false)
      setReviewCanceled(false)
      setSourceError(null)
      setFolderLoading(true)
      try {
        const { tree: newTree, name, reviewableCount, omittedCount } = await buildTreeFromFileList(files)
        if (!selection.isCurrent()) return
        setSourceMode('upload')
        setSourceError(null)
        setTree(newTree)
        setProjectName(name)
        setTargetPath('')
        setSelectedFile(null)
        setOpenFiles([])
        setHighlightRange(null)
        setAnalysisComplete(false)
        setAnalysisRunning(false)
        setReport(null)
        setReportId(null)
        setFindings([])
        setManualReviewCandidates([])
        setProgressSteps([])
        setReviewError(null)
        setPartial(false)
        setReviewCanceled(false)
        setUploadFileCount(reviewableCount)
        setOmittedFileCount(omittedCount)

        // Find first file in tree to open in editor
        const findFirstFile = (nodes: FileNode[]): FileNode | null => {
          for (const n of nodes) {
            if (n.type === 'file' && n.content !== undefined) return n
            if (n.children) {
              const found = findFirstFile(n.children)
              if (found) return found
            }
          }
          return null
        }

        const firstFile = findFirstFile(newTree)
        if (firstFile) {
          setSelectedFile(firstFile)
          setOpenFiles([firstFile])
        }
      } catch (err) {
        if (selection.isCurrent()) setSourceError(err instanceof Error ? 'Could not open folder: ' + err.message : 'Could not open folder. Try selecting it again.')
      } finally {
        if (selection.isCurrent()) setFolderLoading(false)
        if (folderInputRef.current) folderInputRef.current.value = ''
      }
    },
    []
  )

  return {
    // State
    targetPath,
    sourceMode,
    canRunReview,
    uploadFileCount,
    omittedFileCount,
    sourceError,
    reviewCanceled,
    projectName,
    tree,
    selectedFile,
    openFiles,
    analysisRunning,
    analysisComplete,
    findings,
    manualReviewCandidates,
    reportSummary: report?.summary ?? null,
    reportMetrics: report?.metrics ?? null,
    reportOutcome: report ? mapReviewReport(report).outcome : null,
    reportId,
    progressSteps,
    reviewError,
    partial,
    folderLoading,
    highlightRange,
    activeAgent,

    // Methods
    handleSelectFile,
    handleCloseFile,
    handleRunAnalysis,
    handleCancelReview,
    handleChooseServer,
    handleServerPathChange,
    handleFindingClick,
    handleOpenFolder,
    handleFolderInputChange,
    folderInputRef,
  }
}
