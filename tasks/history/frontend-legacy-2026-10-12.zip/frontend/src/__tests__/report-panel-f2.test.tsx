import { describe, expect, it } from 'vitest'
import { renderToStaticMarkup } from 'react-dom/server'
import AgentPanel, { Finding } from '../components/AgentPanel'
import { AgentStepUpdate } from '../types'

const confirmed: Finding = {
  id: 'confirmed-1', agent: 'security', severity: 'high', title: 'Unsafe check',
  description: 'The branch is bypassed.', fileId: 'src/auth.py', fileName: 'auth.py',
  line: 8, startLine: 8, endLine: 10, suggestion: 'Validate permission first.',
  verification_status: 'ACCEPTED', verificationRationale: 'Static evidence confirms it.',
  verificationConfidence: 0.92, confidence_score: 0.84,
  evidence: [{ source: 'ASTStaticAnalyzerTool', line: 8 }],
  codeSnippet: 'if allowed: pass', replacement_code: 'do_not_apply()',
}
const base = {
  analysisRunning: false, analysisComplete: true, canRunReview: true,
  onFindingClick: () => {}, findings: [] as Finding[],
  manualReviewCandidates: [] as Finding[], progressSteps: [] as AgentStepUpdate[],
  reviewError: null, partial: false, sourceMode: 'server' as const,
  sourceLabel: '/fixture', reportId: 'report-123',
  reportSummary: '# DevWatch report\n\nSummary from the backend.',
  reportMetrics: { specialist_tasks: 2, suppressed_findings: 1 },
}
const render = (overrides: Partial<React.ComponentProps<typeof AgentPanel>> = {}) =>
  renderToStaticMarkup(<AgentPanel {...base} {...overrides} />)

describe('F2 report panel', () => {
  it('shows source scope, available ID, summary, and confirmed-only counts', () => {
    const markup = render({ findings: [confirmed], manualReviewCandidates: [{ ...confirmed, id: 'manual-1', title: 'Possible bypass' }], reportOutcome: 'findings' })
    expect(markup).toContain('Confirmed findings (1)')
    expect(markup).toContain('Manual review (1)')
    expect(markup).toContain('report-123')
    expect(markup).toContain('/fixture')
    expect(markup).toContain('Summary from the backend.')
    expect(markup).toContain('2 specialist tasks')
  })

  it('distinguishes clean Git, ordinary empty, manual-only, and empty source', () => {
    expect(render({ reportOutcome: 'clean-git' })).toContain('No Git changes to review')
    expect(render({ reportOutcome: 'no-findings' })).toContain('No confirmed findings')
    expect(render({ reportOutcome: 'manual-only', manualReviewCandidates: [confirmed] })).toContain('Only manual review candidates')
    expect(render({ reportOutcome: 'empty-source' })).toContain('No reviewable source files')
  })

  it('shows source range, verification, evidence, confidence, and guidance only when supplied', () => {
    const detailed = render({ findings: [confirmed], reportOutcome: 'findings' })
    expect(detailed).toContain('src/auth.py:8-10')
    expect(detailed).toContain('Static evidence confirms it.')
    expect(detailed).toContain('ASTStaticAnalyzerTool')
    expect(detailed).toContain('92%')
    expect(detailed).toContain('Validate permission first.')
    expect(detailed).not.toContain('do_not_apply()')
    expect(detailed).not.toContain('Apply fix')
    const sparse = render({ findings: [{ ...confirmed, line: null, startLine: undefined, endLine: undefined, verification_status: undefined, verificationRationale: undefined, verificationConfidence: undefined, confidence_score: undefined, evidence: undefined, codeSnippet: undefined, suggestion: undefined }], reportOutcome: 'findings' })
    expect(sparse).toContain('src/auth.py')
    expect(sparse).not.toContain('src/auth.py:1')
    expect(sparse).not.toContain('Verification rationale')
    expect(sparse).not.toContain('Evidence</')
  })

  it('shows partial stage failures and retains bounded server history after completion', () => {
    const steps: AgentStepUpdate[] = [
      { agent_name: 'Planner', status: 'COMPLETED', message: 'Plan ready', timestamp: 1710000000, elapsed_ms: 1200 },
      { agent_name: 'Verifier', status: 'FAILED', message: 'Tool failed', specialist: 'security', elapsed_ms: 800 },
    ]
    const markup = render({ partial: true, reportOutcome: 'findings', findings: [confirmed], progressSteps: steps, reportMetrics: { partial: true, stage_failures: [{ stage: 'VERIFICATION', component: 'src/auth.py', error_message: 'tool failed' }] } })
    expect(markup).toContain('Partial review')
    expect(markup).toContain('scan-status partial')
    expect(markup).toContain('VERIFICATION')
    expect(markup).toContain('tool failed')
    expect(markup).toContain('Review history (2)')
    expect(markup).toContain('Planner')
    expect(markup).toContain('COMPLETED')
    expect(markup).toContain('Verifier')
    expect(markup).toContain('FAILED')
    expect(markup).toContain('0.8s')
    expect(markup).toContain('UTC')
    expect(markup).toContain('security')
  })

  it('shows upload request progress without specialist claims and hides old report data on failure or cancel', () => {
    const running = render({ analysisRunning: true, analysisComplete: false, sourceMode: 'upload', progressSteps: [{ agent_name: 'Upload request', status: 'RUNNING', message: 'Reviewing uploaded files' }] })
    expect(running).toContain('Upload request')
    expect(running).toContain('Reviewing uploaded files')
    expect(running).not.toContain('specialist task')
    const uploaded = render({ sourceMode: 'upload', reportId: null, reportOutcome: 'no-findings' })
    expect(uploaded).toContain('Uploaded files - whole-file review')
    expect(uploaded).not.toContain('Report ID:')
    const failed = render({ analysisComplete: false, reviewError: 'Review connection failed' })
    expect(failed).toContain('Failed')
    expect(failed).not.toContain('Summary from the backend.')
    const canceled = render({ analysisComplete: false, reviewCanceled: true })
    expect(canceled).toContain('Canceled')
    expect(canceled).not.toContain('report-123')
  })
})
