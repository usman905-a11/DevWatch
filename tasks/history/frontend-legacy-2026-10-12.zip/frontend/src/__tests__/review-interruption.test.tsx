import { describe, expect, it } from 'vitest'
import { renderToStaticMarkup } from 'react-dom/server'
import AgentPanel from '../components/AgentPanel'

const common = {
  analysisRunning: false,
  analysisComplete: false,
  onFindingClick: () => {},
  findings: [],
  manualReviewCandidates: [],
  progressSteps: [],
  partial: false,
}

describe('review interruption states', () => {
  it('asks for a source before presenting the panel as ready', () => {
    const markup = renderToStaticMarkup(
      <AgentPanel
        {...common}
        reviewError={null}
        canRunReview={false}
      />,
    )
    expect(markup).toContain('Choose source')
    expect(markup).not.toContain('>Ready<')
  })

  it('offers a retry and next step when the API connection fails', () => {
    const markup = renderToStaticMarkup(
      <AgentPanel
        {...common}
        reviewError="Review connection failed"
        reviewCanceled={false}
        onRetry={() => {}}
      />,
    )
    expect(markup).toContain('Review connection failed')
    expect(markup).toContain('Check that the DevWatch API is running')
    expect(markup).toContain('Try review again')
  })

  it('labels a canceled review instead of showing ready', () => {
    const markup = renderToStaticMarkup(
      <AgentPanel
        {...common}
        reviewError={null}
        reviewCanceled
        onRetry={() => {}}
      />,
    )
    expect(markup).toContain('Canceled')
    expect(markup).not.toContain('>Ready<')
  })
})