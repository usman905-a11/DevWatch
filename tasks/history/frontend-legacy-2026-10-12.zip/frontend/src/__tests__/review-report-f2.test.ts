import { describe, expect, it } from 'vitest'
import { mapIssuesToFindings, mapReviewReport } from '../hooks/useCodeReview'
import { CodeIssue, ReviewReport } from '../types'

const baseReport: ReviewReport = {
  target_path: '/fixture',
  issues: [],
  manual_review_candidates: [],
  summary: '# DevWatch Code Review Report\n\nNo reviewable Git changes were found.',
  total_issues: 0,
  critical_count: 0,
  high_count: 0,
  medium_count: 0,
  low_count: 0,
  metrics: { partial: false, specialist_tasks: 0, stage_failures: [] },
}

const issue: CodeIssue = {
  finding_id: 'confirmed-1',
  file_path: 'src/auth.py',
  start_line: 8,
  end_line: 10,
  severity: 'HIGH',
  category: 'Security',
  title: 'Unsafe check',
  description: 'The branch is bypassed.',
  suggestion: 'Validate the permission first.',
  verification_status: 'ACCEPTED',
  verification_rationale: 'Static evidence confirms the bypass.',
  verification_confidence: 0.92,
  confidence_score: 0.84,
  evidence: [{ source: 'ASTStaticAnalyzerTool', line: 8 }],
  code_snippet: 'if allowed: pass',
}

describe('F2 report mapping', () => {
  it('preserves summary and metrics and distinguishes a clean Git diff', () => {
    const view = mapReviewReport(baseReport)
    expect(view.summary).toContain('No reviewable Git changes')
    expect(view.metrics).toEqual(baseReport.metrics)
    expect(view.outcome).toBe('clean-git')
    expect(view.findings).toHaveLength(0)
  })

  it('keeps confirmed and manual candidates separate with source evidence', () => {
    const view = mapReviewReport({
      ...baseReport,
      issues: [issue],
      manual_review_candidates: [{ ...issue, finding_id: 'manual-1', title: 'Possible bypass' }],
      summary: 'One confirmed finding and one manual candidate.',
      total_issues: 99,
    })
    expect(view.outcome).toBe('findings')
    expect(view.findings).toHaveLength(1)
    expect(view.manualReviewCandidates).toHaveLength(1)
    expect(view.findings[0]).toMatchObject({
      fileId: 'src/auth.py', line: 8, startLine: 8, endLine: 10,
      verificationRationale: 'Static evidence confirms the bypass.',
      verificationConfidence: 0.92,
      evidence: [{ source: 'ASTStaticAnalyzerTool', line: 8 }],
      codeSnippet: 'if allowed: pass',
    })
  })

  it('distinguishes manual-only, partial, and ordinary empty reports', () => {
    expect(mapReviewReport({ ...baseReport, summary: '', manual_review_candidates: [issue] }).outcome).toBe('manual-only')
    expect(mapReviewReport({ ...baseReport, summary: '', metrics: { partial: true, stage_failures: [{ stage: 'VERIFICATION', component: 'src/auth.py', error_message: 'tool failed' }] } }).partial).toBe(true)
    expect(mapReviewReport({ ...baseReport, summary: 'No confirmed issues were found.' }).outcome).toBe('no-findings')
    expect(mapReviewReport({ ...baseReport, summary: 'Empty repository: no reviewable source files were found.' }).outcome).toBe('empty-source')
  })

  it('does not invent a line or evidence for a sparse finding', () => {
    const sparse = mapIssuesToFindings([{ ...issue, line_number: undefined, start_line: undefined, end_line: undefined, evidence: undefined, verification_rationale: undefined, code_snippet: undefined }])[0]
    expect(sparse.line).toBeNull()
    expect(sparse.evidence).toBeUndefined()
    expect(sparse.verificationRationale).toBeUndefined()
  })
})
