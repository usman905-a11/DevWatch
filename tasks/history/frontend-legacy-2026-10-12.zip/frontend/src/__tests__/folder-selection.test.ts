import { describe, expect, it } from 'vitest'
import { buildTreeFromFileList } from '../hooks/useCodeReview'

function selectedFile(path: string, size: number, read: () => Promise<string>): File {
  return {
    name: path.split('/').pop() || path,
    webkitRelativePath: path,
    size,
    text: read,
  } as unknown as File
}

describe('browser folder preparation', () => {
  it('counts only readable source and omits files that cannot be reviewed', async () => {
    const files = [
      selectedFile('demo/src/app.py', 12, async () => 'print(1)'),
      selectedFile('demo/src/large.py', 2_000_000, async () => 'too large'),
      selectedFile('demo/src/broken.py', 12, async () => { throw new Error('read failed') }),
      selectedFile('demo/src/empty.py', 0, async () => ''),
    ] as unknown as FileList

    const result = await buildTreeFromFileList(files)

    expect(result.name).toBe('demo')
    expect(result.reviewableCount).toBe(1)
    expect(result.omittedCount).toBe(3)
    expect(JSON.stringify(result.tree)).toContain('print(1)')
    const sources = result.tree[0].children || []
    expect(sources.find((file) => file.name === 'large.py')?.unavailableReason).toMatch(/2 MB/)
    expect(sources.find((file) => file.name === 'broken.py')?.unavailableReason).toMatch(/could not read/i)
    expect(sources.find((file) => file.name === 'empty.py')?.unavailableReason).toMatch(/empty/i)
    expect(JSON.stringify(result.tree)).not.toContain('Unreadable or binary content')
    expect(JSON.stringify(result.tree)).not.toContain('Large file')
  })

  it('does not read hidden configuration or dependency files from a selected folder', async () => {
    let excludedReads = 0
    const excluded = async () => { excludedReads += 1; return 'private content' }
    const files = [
      selectedFile('demo/src/app.py', 12, async () => 'print(1)'),
      selectedFile('demo/.env', 12, excluded),
      selectedFile('demo/node_modules/lib.js', 12, excluded),
      selectedFile('demo/package-lock.json', 12, excluded),
      selectedFile('demo/.devwatch/runs/secret.py', 12, excluded),
    ] as unknown as FileList

    const result = await buildTreeFromFileList(files)

    expect(result.reviewableCount).toBe(1)
    expect(result.omittedCount).toBe(4)
    expect(excludedReads).toBe(0)
    expect(JSON.stringify(result.tree)).not.toContain('private content')
  })

  it('rejects a folder with no readable source', async () => {
    const files = [
      selectedFile('demo/empty.py', 0, async () => ''),
      selectedFile('demo/large.py', 2_000_000, async () => 'too large'),
    ] as unknown as FileList

    await expect(buildTreeFromFileList(files)).rejects.toThrow('No readable source files')
  })
})