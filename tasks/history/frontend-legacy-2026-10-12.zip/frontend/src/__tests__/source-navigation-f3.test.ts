import { describe, expect, it, vi } from 'vitest'
import type { FileNode } from '../components/FileExplorer'
import type { Finding } from '../components/AgentPanel'
import { findingRange, resolveSourceFile } from '../review/source'

const a: FileNode = { id: 'src/a/auth.py', name: 'auth.py', type: 'file', content: 'alpha' }
const b: FileNode = { id: 'src/b/auth.py', name: 'auth.py', type: 'file', content: 'beta' }
const tree: FileNode[] = [{ id: 'src', name: 'src', type: 'folder', children: [
  { id: 'src/a', name: 'a', type: 'folder', children: [a] },
  { id: 'src/b', name: 'b', type: 'folder', children: [b] },
] }]

describe('F3 source navigation', () => {
  it('uses exact uploaded paths and never reads the server for uploads', async () => {
    const readServer = vi.fn()
    const result = await resolveSourceFile('src\\b\\auth.py', 'upload', tree, '', readServer)
    expect(result.id).toBe('src/b/auth.py')
    expect(result.content).toBe('beta')
    expect(readServer).not.toHaveBeenCalled()
  })

  it('explains missing and omitted uploaded source without substituting code', async () => {
    const readServer = vi.fn()
    const missing = await resolveSourceFile('src/c/auth.py', 'upload', tree, '', readServer)
    expect(missing.content).toBeUndefined()
    expect(missing.unavailableReason).toMatch(/not included/i)
    const omittedTree: FileNode[] = [{ ...a, content: undefined, unavailableReason: 'This file was too large to upload.' }]
    const omitted = await resolveSourceFile(a.id, 'upload', omittedTree, '', readServer)
    expect(omitted.unavailableReason).toMatch(/too large/i)
    expect(readServer).not.toHaveBeenCalled()
  })

  it('reads server paths only with a selected repository and exposes failures', async () => {
    const readServer = vi.fn().mockResolvedValueOnce({ content: 'from server' }).mockRejectedValueOnce(new Error('permission denied'))
    const loaded = await resolveSourceFile(b.id, 'server', tree, 'C:/repo', readServer)
    expect(loaded.content).toBe('from server')
    expect(readServer).toHaveBeenCalledWith(b.id, 'C:/repo')
    const failed = await resolveSourceFile(b.id, 'server', tree, 'C:/repo', readServer)
    expect(failed.content).toBeUndefined()
    expect(failed.unavailableReason).toMatch(/permission denied/i)
    const noRoot = await resolveSourceFile(b.id, 'server', tree, '', readServer)
    expect(noRoot.unavailableReason).toMatch(/repository path/i)
    expect(readServer).toHaveBeenCalledTimes(2)
  })

  it('keeps the reported start and end range', () => {
    const finding = { line: 2, startLine: 3, endLine: 5 } as Finding
    expect(findingRange(finding)).toEqual({ start: 3, end: 5 })
    expect(findingRange({ ...finding, startLine: undefined, endLine: undefined })).toEqual({ start: 2, end: 2 })
    expect(findingRange({ ...finding, line: null, startLine: undefined })).toBeNull()
  })
})
