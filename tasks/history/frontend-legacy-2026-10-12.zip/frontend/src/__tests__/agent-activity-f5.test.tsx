﻿import { describe, expect, it } from 'vitest'
import { renderToStaticMarkup } from 'react-dom/server'
import AgentPanel from '../components/AgentPanel'
import { AgentStepUpdate } from '../types'

describe('F5 agent activity timeline', () => {
  it('shows scanned files and invoked tools with their responsible agent', () => {
    const progressSteps: AgentStepUpdate[] = [
      {
        agent_name: 'security',
        specialist: 'security',
        status: 'RUNNING',
        message: 'Scanning source file',
        activity: 'file_scan',
        file_path: 'src/auth.py',
      },
      {
        agent_name: 'security',
        specialist: 'security',
        status: 'RUNNING',
        message: 'Calling language model',
        activity: 'tool_call',
        file_path: 'src/auth.py',
        tool_name: 'language_model',
      },
    ]

    const markup = renderToStaticMarkup(
      <AgentPanel
        analysisRunning
        analysisComplete={false}
        canRunReview
        onFindingClick={() => {}}
        findings={[]}
        manualReviewCandidates={[]}
        progressSteps={progressSteps}
        reviewError={null}
        partial={false}
        sourceMode="server"
      />,
    )

    expect(markup).toContain('Agent activity')
    expect(markup).toContain('Tool')
    expect(markup).toContain('language_model')
    expect(markup).toContain('File')
    expect(markup).toContain('src/auth.py')
    expect(markup).toContain('security')
  })
})
