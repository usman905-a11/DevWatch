import type { Finding } from '../components/AgentPanel'
import type { FileNode } from '../components/FileExplorer'
import type { SourceRange } from '../components/CodeEditor'

export type SourceMode = 'server' | 'upload' | null
type ServerRead = (filePath: string, rootPath: string) => Promise<{ content: string }>

function findExactFile(nodes: FileNode[], id: string): FileNode | undefined {
  for (const node of nodes) {
    if (node.type === 'file' && node.id === id) return node
    if (node.children) {
      const match = findExactFile(node.children, id)
      if (match) return match
    }
  }
}

export function findingRange(finding: Finding): SourceRange | null {
  const start = finding.startLine ?? finding.line
  if (start == null || !Number.isInteger(start) || start < 1) return null
  const end = finding.endLine != null && Number.isInteger(finding.endLine) && finding.endLine >= start
    ? finding.endLine : start
  return { start, end }
}

export async function resolveSourceFile(
  filePath: string,
  mode: SourceMode,
  tree: FileNode[],
  rootPath: string,
  readServer: ServerRead,
): Promise<FileNode> {
  const id = filePath.replace(/\\/g, '/')
  const existing = findExactFile(tree, id)
  const file: FileNode = existing ?? {
    id,
    name: id.split('/').pop() || id,
    type: 'file',
    ext: id.includes('.') ? id.split('.').pop()?.toLowerCase() : undefined,
  }

  if (mode === 'upload') {
    if (file.content !== undefined) return file
    return {
      ...file,
      unavailableReason: file.unavailableReason || 'This file was not included in the uploaded folder selection.',
    }
  }
  if (mode !== 'server' || !rootPath.trim()) {
    return { ...file, content: undefined, unavailableReason: 'Choose a server repository path before opening this source.' }
  }
  try {
    const result = await readServer(id, rootPath.trim())
    return { ...file, content: result.content, unavailableReason: undefined }
  } catch (error) {
    const detail = error instanceof Error ? error.message : 'Unknown read error'
    return { ...file, content: undefined, unavailableReason: `Could not read this file from the server: ${detail}` }
  }
}
