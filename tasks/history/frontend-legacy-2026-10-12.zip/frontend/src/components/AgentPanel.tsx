import { AgentStepUpdate, ReviewOutcome } from '../types'

export type AgentId = 'bugs' | 'quality' | 'security'
export type Severity = 'critical' | 'high' | 'medium' | 'low' | 'info'

export interface Finding {
  id: string
  agent: AgentId
  severity: Severity
  title: string
  description: string
  fileId: string
  fileName: string
  line: number | null
  startLine?: number
  endLine?: number
  suggestion?: string
  replacement_code?: string
  finding_id?: string
  verification_status?: string
  cwe_id?: string
  confidence_score?: number
  verificationRationale?: string
  verificationConfidence?: number
  evidence?: Array<Record<string, unknown>>
  codeSnippet?: string
}

interface Props {
  analysisRunning: boolean
  analysisComplete: boolean
  canRunReview?: boolean
  onFindingClick: (f: Finding) => void
  findings: Finding[]
  manualReviewCandidates: Finding[]
  progressSteps: AgentStepUpdate[]
  reviewError: string | null
  reviewCanceled?: boolean
  onRetry?: () => void
  partial: boolean
  reportSummary?: string | null
  reportMetrics?: Record<string, unknown> | null
  reportId?: string | null
  reportOutcome?: ReviewOutcome | null
  sourceMode?: 'server' | 'upload' | null
  sourceLabel?: string
}

function locationOf(finding: Finding): string {
  const start = finding.startLine ?? finding.line
  if (start == null) return finding.fileId
  const end = finding.endLine
  return `${finding.fileId}:${start}${end != null && end > start ? `-${end}` : ''}`
}

function percentage(value?: number): string | null {
  return value == null || !Number.isFinite(value) ? null : `${Math.round(value * 100)}%`
}

function stageFailures(metrics?: Record<string, unknown> | null): Array<{ stage: string; component: string; message: string }> {
  const failures = metrics?.stage_failures
  if (!Array.isArray(failures)) return []
  return failures.filter((item): item is Record<string, unknown> => Boolean(item) && typeof item === 'object' && !Array.isArray(item))
    .map((item) => ({
      stage: typeof item.stage === 'string' ? item.stage : 'Unknown stage',
      component: typeof item.component === 'string' ? item.component : '',
      message: typeof item.error_message === 'string' ? item.error_message : '',
    }))
}

function Card({ finding, onClick, needsReview = false }: {
  finding: Finding
  onClick: () => void
  needsReview?: boolean
}) {
  return (
    <article className={`finding ${finding.severity}`}>
      <div className="finding-top">
        <span className="severity-pill">{finding.severity}</span>
        <span className="location">{locationOf(finding)}</span>
      </div>
      {needsReview && <span className="review-label">Needs manual review - not confirmed</span>}
      <h3 className="finding-title">{finding.title}</h3>
      <p className="finding-description">{finding.description}</p>
      <div className="finding-actions">
        <button type="button" onClick={onClick}>Open source</button>
        <details>
          <summary>Inspect evidence and guidance</summary>
          <div className="finding-detail">
            <p><strong>Location:</strong> {locationOf(finding)}</p>
            {finding.verification_status && <p><strong>Verification:</strong> {finding.verification_status}</p>}
            {finding.verificationRationale && <p><strong>Verification rationale:</strong> {finding.verificationRationale}</p>}
            {percentage(finding.verificationConfidence) && <p><strong>Verification confidence:</strong> {percentage(finding.verificationConfidence)}</p>}
            {percentage(finding.confidence_score) && <p><strong>Finding confidence:</strong> {percentage(finding.confidence_score)}</p>}
            {finding.cwe_id && <p><strong>CWE:</strong> {finding.cwe_id}</p>}
            {finding.codeSnippet && <div><strong>Source excerpt:</strong><pre>{finding.codeSnippet}</pre></div>}
            {finding.evidence && finding.evidence.length > 0 && (
              <div><strong>Evidence:</strong>{finding.evidence.map((item, index) => (
                <pre key={index}>{JSON.stringify(item, null, 2)}</pre>
              ))}</div>
            )}
            {finding.suggestion && <p><strong>Remediation guidance:</strong> {finding.suggestion}</p>}
            <p className="report-only-note">DevWatch reports guidance; it does not edit your files.</p>
          </div>
        </details>
      </div>
    </article>
  )
}

function ActivityMetadata({ step }: { step: AgentStepUpdate }) {
  if (!step.file_path && !step.tool_name) return null
  return (
    <span className="activity-meta">
      {step.file_path && <span><b>File</b><code>{step.file_path}</code></span>}
      {step.tool_name && <span><b>Tool</b><code>{step.tool_name}</code></span>}
    </span>
  )
}

function ProgressHistory({ steps, running }: { steps: AgentStepUpdate[]; running: boolean }) {
  const current = steps[steps.length - 1]
  return (
    <section className="review-progress" aria-label="Agent activity">
      <strong>Agent activity</strong>
      {current ? (
        <p className="current-step" role="status" aria-live={running ? 'polite' : 'off'} aria-atomic="true">
          <span>{current.agent_name}{current.specialist ? ` - ${current.specialist}` : ''}</span>
          <span>{current.status}: {current.message}</span>
          <ActivityMetadata step={current} />
          {current.elapsed_ms != null && <small>{(current.elapsed_ms / 1000).toFixed(1)}s elapsed</small>}
        </p>
      ) : <p>Preparing review...</p>}
      {steps.length > 0 && (
        <details>
          <summary>Review history ({steps.length})</summary>
          <ol>
            {steps.map((step, index) => (
              <li key={`${index}-${step.agent_name}`}>
                <strong>{step.agent_name}{step.specialist ? ` - ${step.specialist}` : ''}</strong>
                <span>{step.status}: {step.message}</span>
                <ActivityMetadata step={step} />
                {step.elapsed_ms != null && <small>{(step.elapsed_ms / 1000).toFixed(1)}s elapsed</small>}
                {step.timestamp != null && Number.isFinite(step.timestamp) && (
                  <time dateTime={new Date(step.timestamp * 1000).toISOString()}>{new Date(step.timestamp * 1000).toISOString().slice(11, 19)} UTC</time>
                )}
              </li>
            ))}
          </ol>
        </details>
      )}
    </section>
  )
}

const emptyMessages: Record<Exclude<ReviewOutcome, 'findings'>, { title: string; detail: string }> = {
  'clean-git': { title: 'No Git changes to review', detail: 'The selected repository has no reviewable staged, unstaged, or untracked source changes.' },
  'empty-source': { title: 'No reviewable source files', detail: 'The selected server folder did not contain source files the reviewer could inspect.' },
  'no-findings': { title: 'No confirmed findings', detail: 'The review completed without confirming an issue in the selected source.' },
  'manual-only': { title: 'Only manual review candidates', detail: 'No issue was confirmed. Inspect the candidates below before deciding whether to act.' },
}

export default function AgentPanel({
  analysisRunning, analysisComplete, canRunReview = true, onFindingClick,
  findings = [], manualReviewCandidates = [], progressSteps = [], reviewError,
  reviewCanceled = false, onRetry, partial, reportSummary, reportMetrics,
  reportId, reportOutcome, sourceMode, sourceLabel,
}: Props) {
  const connectionError = Boolean(reviewError && /connect|websocket|closed/i.test(reviewError))
  const failures = stageFailures(reportMetrics)
  const emptyMessage = reportOutcome && reportOutcome !== 'findings'
    ? emptyMessages[reportOutcome]
    : emptyMessages['no-findings']
  const specialistTasks = typeof reportMetrics?.specialist_tasks === 'number' ? reportMetrics.specialist_tasks : null
  const suppressedFindings = typeof reportMetrics?.suppressed_findings === 'number' ? reportMetrics.suppressed_findings : null

  return (
    <aside id="review-results" className="agents" aria-label="Code review results" tabIndex={-1}>
      <div className="agent-head">
        <div>
          <span className="eyebrow">Code review</span>
          <h1>Confirmed findings ({findings.length})</h1>
        </div>
        <span className={`scan-status ${analysisRunning ? 'scanning' : reviewError ? 'failed' : reviewCanceled ? 'canceled' : analysisComplete ? partial ? 'partial' : 'complete' : ''}`} role="status" aria-live="polite" aria-atomic="true">
          {analysisRunning ? 'Reviewing' : reviewError ? 'Failed' : reviewCanceled ? 'Canceled' : partial ? 'Partial' : analysisComplete ? 'Complete' : canRunReview ? 'Ready' : 'Choose source'}
        </span>
      </div>

      {(analysisRunning || progressSteps.length > 0) && <ProgressHistory steps={progressSteps} running={analysisRunning} />}

      {reviewError && (
        <div className="review-error" role="alert">
          <strong>Review failed: {reviewError}</strong>
          <p>{connectionError ? 'Check that the DevWatch API is running, then retry.' : 'Check the selected source and retry.'}</p>
          {onRetry && <button type="button" onClick={onRetry}>Try review again</button>}
        </div>
      )}
      {analysisComplete && partial && (
        <div className="review-partial" role="status">
          <strong>Partial review:</strong> some analysis stages failed. Confirmed findings below passed verification.
          {failures.length > 0 && (
            <ul>{failures.map((failure, index) => (
              <li key={index}>{failure.stage}{failure.component ? ` (${failure.component})` : ''}{failure.message ? `: ${failure.message}` : ''}</li>
            ))}</ul>
          )}
        </div>
      )}
      {analysisComplete && (
        <section className="report-overview" aria-label="Report overview">
          <h2>Report overview</h2>
          <p><strong>Review scope:</strong> {sourceMode === 'upload' ? 'Uploaded files - whole-file review' : 'Server path - Git changes when available'}{sourceLabel ? `: ${sourceLabel}` : ''}</p>
          {reportId && <p><strong>Report ID:</strong> <code>{reportId}</code></p>}
          {(specialistTasks != null || suppressedFindings != null) && (
            <p>{specialistTasks != null && <span>{specialistTasks} specialist {specialistTasks === 1 ? 'task' : 'tasks'}</span>}{specialistTasks != null && suppressedFindings != null && ' / '}{suppressedFindings != null && <span>{suppressedFindings} suppressed candidates</span>}</p>
          )}
          {reportSummary && <div><strong>Report summary</strong><pre>{reportSummary}</pre></div>}
        </section>
      )}

      <div className="finding-list">
        {!analysisComplete && !analysisRunning && !reviewError && (
          <div className="review-blank">
            <strong>{reviewCanceled ? 'Review canceled' : 'Review findings'}</strong>
            <p>{reviewCanceled ? 'Run review when you are ready to try again.' : canRunReview ? 'Run a review to inspect confirmed findings and manual review candidates.' : 'Choose a review source above to get started.'}</p>
          </div>
        )}
        {analysisRunning && progressSteps.length === 0 && <div className="skeleton" aria-hidden="true" />}
        {analysisComplete && findings.length === 0 && (
          <div className="review-blank"><strong>{emptyMessage.title}</strong><p>{emptyMessage.detail}</p></div>
        )}
        {analysisComplete && findings.map((finding) => (
          <Card key={finding.id} finding={finding} onClick={() => onFindingClick(finding)} />
        ))}
        {analysisComplete && manualReviewCandidates.length > 0 && (
          <section className="manual-review" aria-label="Manual review candidates">
            <h2>Manual review ({manualReviewCandidates.length})</h2>
            <p>These candidates are unconfirmed and need a person to check the evidence.</p>
            {manualReviewCandidates.map((finding) => (
              <Card key={finding.id} finding={finding} needsReview onClick={() => onFindingClick(finding)} />
            ))}
          </section>
        )}
      </div>

      {analysisComplete && (
        <div className="summary">
          {(['critical', 'high', 'medium', 'low', 'info'] as Severity[]).map((severity) => {
            const count = findings.filter((finding) => finding.severity === severity).length
            return count ? <span key={severity} className={severity}><i aria-hidden="true" />{count} {severity}</span> : null
          })}
          {manualReviewCandidates.length > 0 && <span>{manualReviewCandidates.length} to review</span>}
        </div>
      )}
    </aside>
  )
}
