import { useEffect, useMemo, useRef, useState } from 'react'
import type { FileNode } from './FileExplorer'

export interface SourceRange { start: number; end: number }

interface Props {
  file: FileNode | null
  openFiles: FileNode[]
  onSelectFile: (file: FileNode) => void
  onCloseFile: (id: string) => void
  highlightRange: SourceRange | null
  sourceMode?: 'server' | 'upload' | null
}

const LINE_HEIGHT = 21
const OVERSCAN = 12
const MAX_PREVIEW_LINE_LENGTH = 5000

const token = (source: string) => source
  .split(/(\/\/.*|"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|`[^`]*`|\b(?:import|export|from|const|let|var|return|async|await|function|def|class|if|else|elif|interface|type|new|throw|try|catch|except|finally|true|false|null|undefined|None|True|False)\b|\b\d+\b)/g)
  .map((part, index) => {
    const className = part.startsWith('//') || part.startsWith('#') ? 'comment'
      : /^['"`]/.test(part) ? 'string'
        : /^(import|export|from|const|let|var|return|async|await|function|def|class|if|else|elif|interface|type|new|throw|try|catch|except|finally|true|false|null|undefined|None|True|False)$/.test(part) ? 'keyword'
          : /^\d+$/.test(part) ? 'number' : ''
    return <span key={index} className={className}>{part}</span>
  })

export default function CodeEditor({
  file, openFiles, onSelectFile, onCloseFile, highlightRange, sourceMode,
}: Props) {
  const codeRef = useRef<HTMLDivElement>(null)
  const [scrollTop, setScrollTop] = useState(0)
  const [viewportHeight, setViewportHeight] = useState(600)
  const lines = useMemo(() => file?.content ? file.content.split('\n') : [], [file?.content])
  const hasLongLines = useMemo(() => lines.some((line) => line.length > MAX_PREVIEW_LINE_LENGTH), [lines])
  const rangeStart = highlightRange?.start ?? null
  const rangeEnd = highlightRange?.end ?? null

  useEffect(() => {
    const element = codeRef.current
    if (!element) return
    const measure = () => setViewportHeight(element.clientHeight || 600)
    measure()
    if (typeof ResizeObserver === 'undefined') return
    const observer = new ResizeObserver(measure)
    observer.observe(element)
    return () => observer.disconnect()
  }, [file?.id, file?.content])

  useEffect(() => {
    const element = codeRef.current
    if (!element) return
    const target = rangeStart != null && rangeStart > 0
      ? Math.max(0, (rangeStart - 1) * LINE_HEIGHT - element.clientHeight / 2)
      : 0
    element.scrollTop = target
    setScrollTop(element.scrollTop)
  }, [file?.id, file?.content, rangeStart])

  const first = Math.max(0, Math.floor(scrollTop / LINE_HEIGHT) - OVERSCAN)
  const last = Math.min(lines.length, Math.ceil((scrollTop + viewportHeight) / LINE_HEIGHT) + OVERSCAN)
  const outOfRange = rangeStart != null && (rangeStart < 1 || rangeStart > lines.length)

  return (
    <main id="source-pane" className="editor" aria-label="Source preview" tabIndex={-1}>
      <nav className="tabs" aria-label="Open source files">
        {openFiles.map((openFile) => (
          <div key={openFile.id} className={`tab ${openFile.id === file?.id ? 'active' : ''}`}>
            <button
              type="button"
              className="tab-select"
              aria-label={`Select ${openFile.id}`}
              aria-current={openFile.id === file?.id ? 'true' : undefined}
              onClick={() => onSelectFile(openFile)}
            >{openFile.name}</button>
            <button
              type="button"
              className="tab-close"
              aria-label={`Close ${openFile.id}`}
              onClick={() => onCloseFile(openFile.id)}
            >x</button>
          </div>
        ))}
      </nav>

      {file ? (
        <>
          <div className="editor-meta">
            <span>{file.id}</span>
            <span>Read-only source preview</span>
          </div>
          {file.content === undefined ? (
            <div className="source-unavailable" role="status">
              <h2>Source unavailable</h2>
              <p>{file.unavailableReason || 'The selected source could not be displayed.'}</p>
              {sourceMode === 'server' && <button type="button" onClick={() => onSelectFile(file)}>Retry loading source</button>}
            </div>
          ) : file.content === '' ? (
            <div className="source-unavailable" role="status"><h2>Empty file</h2><p>This source file has no content to preview.</p></div>
          ) : (
            <>
              {(outOfRange || hasLongLines) && (
                <div className="source-notice" role="status">
                  {outOfRange && <p>Reported line {rangeStart} is outside this {lines.length}-line file.</p>}
                  {hasLongLines && <p>Lines over {MAX_PREVIEW_LINE_LENGTH} characters are truncated in this preview.</p>}
                </div>
              )}
              <div
                ref={codeRef}
                className="code"
                role="region"
                aria-label="Read-only source preview"
                tabIndex={0}
                onScroll={(event) => setScrollTop(event.currentTarget.scrollTop)}
              >
                <div className="code-spacer" style={{ height: first * LINE_HEIGHT }} aria-hidden="true" />
                {lines.slice(first, last).map((line, index) => {
                  const lineNumber = first + index + 1
                  const flagged = rangeStart != null && lineNumber >= rangeStart && lineNumber <= (rangeEnd ?? rangeStart)
                  const preview = line.length > MAX_PREVIEW_LINE_LENGTH
                    ? `${line.slice(0, MAX_PREVIEW_LINE_LENGTH)}... [preview truncated]`
                    : line
                  return (
                    <div key={lineNumber} className={`line ${flagged ? 'flagged' : ''}`}>
                      <span className="line-number" aria-hidden="true">{lineNumber}</span>
                      <code aria-label={`Line ${lineNumber}`}>{token(preview)}</code>
                    </div>
                  )
                })}
                <div className="code-spacer" style={{ height: (lines.length - last) * LINE_HEIGHT }} aria-hidden="true" />
              </div>
            </>
          )}
        </>
      ) : (
        <div className="empty-editor">
          <span className="empty-kicker">Source preview</span>
          <h2>Read-only source preview</h2>
          <p>Choose a source file to inspect it here, or run a review to find a location.</p>
        </div>
      )}
    </main>
  )
}
