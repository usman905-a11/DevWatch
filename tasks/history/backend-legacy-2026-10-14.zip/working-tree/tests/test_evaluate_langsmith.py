import importlib
from pathlib import Path

import pytest

from devwatch.models import CodeIssue, IssueSeverity, ReviewReport
from devwatch.review import factory as review_factory


def _evaluation_module():
    try:
        return importlib.import_module("evaluate_langsmith")
    except ModuleNotFoundError:
        pytest.fail("evaluate_langsmith.py has not been implemented")


class RecordingEngine:
    def __init__(self, report=None, error=None):
        self.report = report
        self.error = error
        self.calls = []

    async def review_file(self, file_path, content):
        self.calls.append((file_path, content))
        if self.error is not None:
            raise self.error
        return self.report


@pytest.mark.asyncio
async def test_review_target_maps_dataset_input_and_normalizes_review(monkeypatch):
    module = _evaluation_module()
    factory_options = {}
    issue = CodeIssue(
        file_path="evaluation_input.py",
        line_number=2,
        severity=IssueSeverity.HIGH,
        category="Concurrency",
        title="Lost update",
        description="A shared counter update can lose writes.",
        suggestion="Protect the update with a lock.",
    )
    report = ReviewReport(
        target_path="evaluation_input.py",
        issues=[issue],
        metrics={"confirmed_findings": 1},
        summary="One confirmed issue.",
    )
    engine = RecordingEngine(report=report)

    def fake_engine_factory(**options):
        factory_options.update(options)
        return engine

    monkeypatch.setattr(module, "create_review_engine", fake_engine_factory)

    output = await module.review_target(
        {"code": "counter += 1\n", "language": "Python"}
    )

    assert engine.calls == [("evaluation_input.py", "counter += 1\n")]
    assert factory_options == {
        "runs_dir": Path(".devwatch/langsmith-evaluation/runs"),
        "checkpoint_path": Path(".devwatch/langsmith-evaluation/checkpoints.sqlite"),
    }
    assert output == {
        "clean": False,
        "issues": [
            {
                "category": "concurrency",
                "description": "A shared counter update can lose writes.",
                "severity": "high",
                "title": "Lost update",
                "recommendation": "Protect the update with a lock.",
                "file_path": "evaluation_input.py",
                "start_line": 2,
                "end_line": 2,
            }
        ],
        "manual_review_candidates": [],
        "summary": "One confirmed issue.",
        "metrics": {"confirmed_findings": 1},
    }


@pytest.mark.asyncio
async def test_review_target_marks_manual_candidates_as_not_clean(monkeypatch):
    module = _evaluation_module()
    candidate = CodeIssue(
        file_path="evaluation_input.js",
        line_number=1,
        severity=IssueSeverity.MEDIUM,
        category="Correctness",
        title="Possible stale value",
        description="The callback may read stale state.",
        suggestion="Use the functional update form.",
    )
    engine = RecordingEngine(
        report=ReviewReport(
            target_path="evaluation_input.js",
            manual_review_candidates=[candidate],
        )
    )
    monkeypatch.setattr(module, "create_review_engine", lambda **_options: engine)

    output = await module.review_target(
        {"code": "value += 1;\n", "language": "javascript"}
    )

    assert engine.calls == [("evaluation_input.js", "value += 1;\n")]
    assert output["clean"] is False
    assert output["issues"] == []
    assert output["manual_review_candidates"][0]["severity"] == "medium"


@pytest.mark.parametrize(
    ("inputs", "message"),
    [
        ({"language": "python"}, "missing required dataset field: code"),
        ({"code": "pass\n"}, "missing required dataset field: language"),
        ({"code": 42, "language": "python"}, "code must be a string"),
        ({"code": "pass\n", "language": "brainfuck"}, "unsupported language"),
    ],
)
@pytest.mark.asyncio
async def test_review_target_rejects_malformed_dataset_inputs(inputs, message):
    module = _evaluation_module()

    with pytest.raises((TypeError, ValueError), match=message):
        await module.review_target(inputs)


@pytest.mark.asyncio
async def test_review_target_preserves_graph_failure_context(monkeypatch):
    module = _evaluation_module()
    engine = RecordingEngine(error=OSError("provider unavailable"))
    monkeypatch.setattr(module, "create_review_engine", lambda **_options: engine)

    with pytest.raises(RuntimeError, match="DevWatch review failed for python") as caught:
        await module.review_target({"code": "pass\n", "language": "python"})

    assert isinstance(caught.value.__cause__, OSError)


@pytest.mark.asyncio
async def test_run_experiment_uses_async_langsmith_evaluation(monkeypatch):
    module = _evaluation_module()
    captured = {}
    sentinel = object()

    async def fake_aevaluate(target, **kwargs):
        captured["target"] = target
        captured.update(kwargs)
        return sentinel

    monkeypatch.setattr(module, "aevaluate", fake_aevaluate)

    result = await module.run_experiment()

    assert result is sentinel
    assert captured == {
        "target": module.review_target,
        "data": "langsmith_multi_agent_code_review_dataset",
        "experiment_prefix": "code-review-v1",
        "description": "DevWatch production multi-agent code review workflow",
        "max_concurrency": 1,
        "error_handling": "log",
    }


def test_review_engine_factory_accepts_isolated_storage(monkeypatch):
    runs_dir = Path("isolated-runs")
    checkpoint_path = Path("isolated-checkpoints.sqlite")
    captured = {}
    sentinel = object()

    def fake_review_engine(**options):
        captured.update(options)
        return sentinel

    monkeypatch.setattr(review_factory, "ReviewEngine", fake_review_engine)

    engine = review_factory.create_review_engine(
        runs_dir=runs_dir,
        checkpoint_path=checkpoint_path,
    )

    assert engine is sentinel
    assert captured["runs_dir"] == runs_dir
    assert captured["checkpoint_path"] == checkpoint_path
