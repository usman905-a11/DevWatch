﻿"""F5 live-agent activity contract and transport tests."""

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from devwatch.config import Config
from devwatch.models import AgentStepUpdate, ReviewReport
from devwatch.review.engine import ReviewEngine
from devwatch.server import app
from devwatch.storage import ReportStorage


class EmptyAgent:
    async def execute(self, _context):
        return []


@pytest.mark.parametrize("unsafe_path", ["../secret.env", "/etc/passwd", "C:/Users/secret.txt"])
def test_agent_activity_rejects_paths_outside_review_scope(unsafe_path):
    with pytest.raises(ValidationError):
        AgentStepUpdate(
            agent_name="security",
            status="RUNNING",
            message="Scanning file",
            activity="file_scan",
            file_path=unsafe_path,
        )


def test_agent_activity_normalizes_relative_file_and_exposes_only_named_tool():
    update = AgentStepUpdate(
        agent_name="security",
        status="RUNNING",
        message="Calling static analyzer",
        activity="tool_call",
        file_path=r"src\auth.py",
        tool_name="ASTStaticAnalyzerTool",
    )

    payload = update.model_dump(mode="json")
    assert payload["activity"] == "tool_call"
    assert payload["file_path"] == "src/auth.py"
    assert payload["tool_name"] == "ASTStaticAnalyzerTool"
    assert "tool_arguments" not in payload
    assert "file_content" not in payload


@pytest.mark.asyncio
async def test_engine_emits_file_and_tool_activity_at_execution_boundaries(tmp_path):
    updates = []
    engine = ReviewEngine(
        planner=EmptyAgent(),
        specialists={},
        verifier=EmptyAgent(),
        runs_dir=tmp_path / "runs",
        run_commands=False,
    )

    await engine.review_file("src/app.py", "print('safe')\n", progress_sink=updates.append)

    activities = [
        (update.activity, update.agent_name, update.file_path, update.tool_name)
        for update in updates
    ]
    assert ("file_scan", "Static analyzer", "src/app.py", None) in activities
    assert (
        "tool_call",
        "Static analyzer",
        "src/app.py",
        "ASTStaticAnalyzerTool",
    ) in activities
    assert any(
        activity == "tool_call" and agent == "Planner Agent" and tool == "language_model"
        for activity, agent, _path, tool in activities
    )


def test_websocket_streams_uploaded_file_activity_and_completion(monkeypatch, tmp_path):
    from devwatch import reports
    from devwatch.routers import ws

    monkeypatch.setattr(Config, "API_KEY", None)
    monkeypatch.setattr(reports, "report_storage", ReportStorage(str(tmp_path / "reports")))
    received = {}

    async def reject_repository(*_args, **_kwargs):
        raise AssertionError("uploaded reviews must not call repository review")

    async def audit_upload(
        self, files, client_identity, client_ip, step_callback=None
    ):
        received["files"] = files
        step_callback(AgentStepUpdate(
            agent_name="Static analyzer",
            status="RUNNING",
            message="Scanning src/app.py",
            activity="file_scan",
            file_path="src/app.py",
        ))
        return ReviewReport(target_path="uploaded_workspace", summary="# Done")

    monkeypatch.setattr(ws.ReviewOperations, "audit_repository", reject_repository)
    monkeypatch.setattr(ws.ReviewOperations, "audit_uploaded_files", audit_upload)

    with TestClient(app) as client:
        with client.websocket_connect("/ws/review") as socket:
            socket.send_json({
                "files": [{"file_path": "src/app.py", "content": "print('safe')\n"}]
            })
            progress = socket.receive_json()
            completion = socket.receive_json()

    assert received["files"][0]["file_path"] == "src/app.py"
    assert progress["type"] == "agent_update"
    assert progress["activity"] == "file_scan"
    assert progress["file_path"] == "src/app.py"
    assert completion["type"] == "review_completion"
    assert completion["report"]["target_path"] == "uploaded_workspace"


def test_stage_only_agent_update_remains_backward_compatible():
    update = AgentStepUpdate(
        agent_name="planner",
        status="RUNNING",
        message="Planning",
    )
    payload = update.model_dump(mode="json")
    assert payload["activity"] == "stage"
    assert payload["file_path"] is None
    assert payload["tool_name"] is None


@pytest.mark.asyncio
async def test_uploaded_websocket_disconnect_cancels_review(monkeypatch):
    import asyncio

    from devwatch.routers import ws

    started = asyncio.Event()
    cancelled = asyncio.Event()

    async def audit_upload(
        self, files, client_identity, client_ip, step_callback=None
    ):
        started.set()
        try:
            await asyncio.Event().wait()
        finally:
            cancelled.set()

    class Socket:
        client = None

        async def accept(self):
            pass

        async def receive_json(self):
            return {"files": [{"file_path": "app.py", "content": "pass\n"}]}

        async def receive(self):
            await started.wait()
            return {"type": "websocket.disconnect"}

        async def send_json(self, payload):
            raise AssertionError(f"unexpected message: {payload}")

        async def close(self):
            pass

    async def authenticate(_socket):
        return "test-client"

    monkeypatch.setattr(ws, "authenticate_ws_connection", authenticate)
    monkeypatch.setattr(ws.ReviewOperations, "audit_uploaded_files", audit_upload)
    await asyncio.wait_for(ws.websocket_review_endpoint(Socket()), timeout=2)
    assert cancelled.is_set()


def test_configured_tool_names_are_canonical_and_bounded():
    assert ReviewEngine._safe_tool_name("npm test / workspace") == "npm_test_workspace"
    assert len(ReviewEngine._safe_tool_name("x" * 200)) == 80
