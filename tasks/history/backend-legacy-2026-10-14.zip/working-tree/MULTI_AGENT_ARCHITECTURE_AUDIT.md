# DevWatch Multi-Agent Architecture and System-Design Audit

Audit date: 2026-10-07  
Repository: `E:\dewatch`  
Base commit: `e27a775438867a0a13d0453dffe34e9f92c0d120`  
Scope: The working tree at audit time, including staged, unstaged, and untracked work.

This document preserves the findings from the architecture audit. Recommendations are not implemented changes. No application code was changed during the audit or while saving this report. Tests, builds, browser flows, and live model calls were not run; runtime-dependent conclusions remain unverified. Historical evaluation results are identified separately from fresh source inspection.

## 1. Executive Summary

**Your LangGraph workflow is structurally reasonable, but the system is not production ready.** The main problems are review coverage, evidence handling, failure semantics, and execution isolation—not the basic choice of LangGraph or parallel specialists.

The strongest parts of the current implementation are:

- A finite graph with conditional specialist fan-out and deterministic final rendering.
- Reducers on the fields written by parallel specialists.
- Pydantic models for tasks, findings, and model responses.
- Protection against the verifier inventing findings or rewriting their severity.
- A final gate that checks source locations and evidence fingerprints.
- Checkpointing, partial-result handling, provider error classification, and offline test doubles.

The most consequential problems are:

| Finding | Consequence |
|---|---|
| Repository test commands execute on the host without OS isolation. | Reviewing an untrusted repository can execute its code with host permissions. |
| Selected dependency context, changed regions, and command evidence are not included in specialist prompts. | Several agents cannot perform the cross-file reasoning their prompts promise. |
| File limits are applied before changed-file selection. | Changed files outside the discovery limit disappear, potentially producing a misleading clean result. |
| Missing providers and exhausted structured-output attempts can become empty successful results. | “No findings” does not reliably mean “successfully reviewed.” |
| Nonconclusive static findings cannot pass the final gate, even after positive verification. | An entire class of static candidates is permanently suppressed. |
| Selected heuristic static rules bypass verification with confidence `1.0`. | Detecting a suspicious construct is treated as proof of a defect. |
| Verification fields default to acceptance and high confidence. | Incomplete verifier responses can authorize findings without explicit reasoning. |
| REST and WebSocket identities differ for the same API key. | Reports saved through WebSockets cannot be retrieved through REST in production. |
| Full-file batching has no effective prompt token limit. | Larger reviews risk context overflow, expensive retries, and incomplete findings. |

A saved evaluation export provides historical evidence of the quality problem: **6 of 22 buggy examples were detected—27.3% example-level recall.** Eight misses produced no candidates; eight produced candidates that were suppressed. This does not establish the cause of each miss, and it is not a fresh evaluation of this worktree.

**Audit scope:** I inspected the current backend, frontend, graph, agents, prompts, providers, tools, persistence, configuration, tests, evaluation code, and saved evaluation results. The audited worktree contains substantial staged, unstaged, and untracked changes; this report describes that worktree, not just the base commit.

**No application files were changed.** Tests, builds, and live model calls were not run. The available execution environment could not provide the isolation needed to execute repository code safely. Runtime-dependent conclusions are identified below.

## 2. Repository / System Overview

The application is DevWatch: a Python review backend with a React frontend.

| Area | Actual implementation |
|---|---|
| CLI | `devwatch.cli:app`; invokes `ReviewPipeline.execute()` |
| Backend | FastAPI application in [server.py](devwatch/server.py) |
| Browser application | React/Vite; review lifecycle managed by [useCodeReview.ts](frontend/src/hooks/useCodeReview.ts) |
| Transport layer | REST review/filesystem/report routes and `/ws/review` |
| Application operations | `ReviewOperations` validates and dispatches review requests |
| Compatibility facade | `ReviewPipeline` in [dag.py](devwatch/pipeline/dag.py), line 152 |
| Active orchestrator | `ReviewEngine` in [engine.py](devwatch/review/engine.py), line 44 |
| Active agents | `RiskPlannerAgent`, four `RoleReviewAgent` instances, `StrictVerifierAgent` |
| Model integration | OpenAI-compatible adapter supporting Gemini, OpenAI, and OpenRouter configurations |
| Persistence | SQLite LangGraph checkpoints, run artifacts, JSON report records |
| Observability | LangGraph tracing, `wrap_openai`, application logs, streamed progress events |
| Evaluation | `evaluate_langsmith.py`, offline fixtures, historical LangSmith CSV exports |

Important distinctions:

1. **The default runtime does not use the old planner/security/quality/synthesizer chain.** Those classes remain as compatibility components.
2. **`ReviewPipeline` is a facade.** The active LangGraph definition belongs to `ReviewEngine`.
3. **The active final report is rendered deterministically.** `ReportSynthesizerAgent` is constructed by the facade but does not generate the default report.
4. **There are four specialist roles, but they share one implementation.** Specialization primarily comes from role instructions.
5. **The active agents do not autonomously call tools.** The engine invokes deterministic helpers before or after model calls.
6. **Repository reviews normally review working-tree changes against `HEAD`.** A clean Git repository returns without running the graph. Uploaded files are reviewed as full-file inputs.

Software engineering assessment:

- Dependency injection is useful, but agent inputs remain arbitrary dictionaries.
- The active engine combines preprocessing, orchestration, artifact access, progress reporting, verification, and report construction in one large module.
- Configuration contains overlapping and unused limits.
- Active and legacy schemas, prompts, verification strategies, and chunkers create maintenance ambiguity.
- Injecting any facade component changes checkpointing to memory, even when the injected component is unused.
- `requires-python = ">=3.10"` conflicts with unconditional `tomllib` imports and `asyncio.timeout`, which require Python 3.11.

## 3. Current Architecture

The architecture is a **hybrid planner–executor workflow with conditional parallel specialists and a deterministic aggregation pipeline**.

It is not a conversational supervisor, peer-to-peer agent network, or autonomous tool-using agent system.

### Repository review path

`CLI / REST / WebSocket`  
→ `ReviewOperations` where applicable  
→ `ReviewPipeline.execute()`  
→ `ReviewEngine.review_repository()`  
→ scanner discovery  
→ Git changed-region collection  
→ dependency/test-context selection  
→ snapshot creation  
→ optional repository command execution  
→ static candidates  
→ LangGraph execution  
→ deterministic report  
→ transport response and, for selected transports, report persistence.

### Uploaded-file path

`REST / WebSocket files`  
→ `ReviewOperations`  
→ `ReviewPipeline.arun_file_audit()` or `arun_files_audit()`  
→ `ReviewEngine.review_files()`  
→ uploaded-file snapshot  
→ whole-file changed regions  
→ static candidates  
→ the same graph.

Uploaded-file reviews do **not** run repository verification commands.

### Source-derived execution example

Consider an uploaded `auth.py` containing a call to `eval(user_input)`:

1. The browser sends file content through `/ws/review`.
2. The WebSocket route authenticates, validates the request shape, creates an operation, and starts review/progress/disconnect tasks.
3. `review_files()` builds the input mapping and creates a run artifact.
4. The entire file becomes a `ChangedRegion`.
5. `_static_findings()` detects the `eval()` call.
6. That title belongs to the engine’s “conclusive” allowlist, so the static candidate receives acceptance and verification confidence `1.0`.
7. `plan_review` routes the file. With the deterministic fallback, `auth.py` triggers correctness and security coverage.
8. Selected specialists run through separate `Send` invocations.
9. Their findings and the static candidate enter the candidate reducer.
10. `deduplicate` combines candidates.
11. `verify` bypasses the LLM for the conclusive static candidate and verifies remaining candidates per file.
12. `strict_gate` checks locations, evidence, status, and confidence.
13. `render_report` builds the report.
14. The WebSocket route saves the report and sends a completion frame.

This is a walkthrough of source behavior, **not an executed trace**. It also illustrates why static-rule conclusiveness needs stronger semantics.

## 4. Current Architecture Diagram

```mermaid
flowchart TD
    Browser["React frontend"] --> WS["WebSocket /ws/review"]
    Browser --> REST["REST review and filesystem APIs"]
    CLI["Typer CLI"] --> Facade["ReviewPipeline"]

    WS --> Ops["ReviewOperations"]
    REST --> Ops
    Ops --> Facade
    Facade --> Engine["ReviewEngine"]

    Engine --> Repo{"Input mode"}

    Repo -->|Repository| Scan["Scanner + Git changed regions"]
    Scan --> Context["Select dependency and test context"]
    Context --> Snapshot["Workspace snapshot"]
    Snapshot --> Commands["Optional host test commands"]
    Commands --> Static["Static analysis"]

    Repo -->|Uploaded files| Upload["Validate paths + create artifacts"]
    Upload --> Static

    Static --> Graph["LangGraph review workflow"]
    Graph --> Provider["OpenAI-compatible provider"]
    Provider --> External["Gemini / OpenAI / OpenRouter"]

    Graph --> Checkpoints["SQLite checkpoints"]
    Snapshot --> Artifacts["Run artifact storage"]
    Upload --> Artifacts

    Graph --> Report["Deterministic ReviewReport"]
    Report --> Response["CLI / REST / WebSocket response"]
    Report --> Saved["Saved reports: repository REST and WebSocket"]

    Graph -. tracing .-> LangSmith["LangSmith"]
    Provider -. wrapped model calls .-> LangSmith
    Engine -. progress .-> WS
```

The diagram shows the current implementation. “Select dependency and test context” means the engine selects and loads it; the default specialist prompt currently omits it.

## 5. LangGraph Execution Diagram

The graph is defined in [ReviewEngine._build_graph()](devwatch/review/engine.py), line 347.

```mermaid
flowchart TD
    START((START)) --> Plan["plan_review"]

    Plan --> Dispatch{"_dispatch_tasks"}
    Dispatch -->|No tasks| Dedup["deduplicate"]
    Dispatch -->|Send per normalized task| Specialists["run_specialist × selected roles"]

    Specialists --> Merge["Reducers collect candidates and failures"]
    Merge --> Dedup

    Dedup --> Verify["verify"]
    Verify --> StaticPass["Conclusive static findings bypass model"]
    Verify --> ModelVerify["Other findings: sequential verification per file"]

    StaticPass --> Gate["strict_gate"]
    ModelVerify --> Gate
    Gate --> Render["render_report"]
    Render --> END((END))

    Plan -. model call .-> Retry["Bounded schema repair + provider retries"]
    Specialists -. model calls .-> Retry
    ModelVerify -. model calls .-> Retry
```

`StaticPass`, `ModelVerify`, `Merge`, and `Retry` illustrate internal behavior; they are **not additional registered graph nodes**.

The registered nodes are exactly:

| Node | Function |
|---|---|
| `plan_review` | `_plan_review()` |
| `run_specialist` | `_run_specialist()` |
| `deduplicate` | `_deduplicate()` |
| `verify` | `_verify()` |
| `strict_gate` | `_strict_gate()` |
| `render_report` | `_render_report()` |

The same `run_specialist` node receives multiple private task states. Under LangGraph’s superstep execution model, those branches execute in parallel and their updates are reduced before the next stage. The fan-in is consistent with the documented `Send` pattern. [LangGraph Graph API](https://docs.langchain.com/oss/python/langgraph/graph-api)

**Termination paths:**

- Tasks exist: `START → plan_review → run_specialist → deduplicate → verify → strict_gate → render_report → END`.
- No tasks: `START → plan_review → deduplicate → verify → strict_gate → render_report → END`.
- Handled planning/specialist/verifier errors: recorded failures proceed toward the report.
- Unhandled preprocessing, checkpoint, deduplication, or rendering errors: execution raises instead of reaching a successful report.
- Cancellation/deadline: execution stops with an exception.
- Clean/empty repository: preprocessing returns before graph execution.

There are no supervisor loops, backward edges, or graph-level retry loops. A finite graph does not, however, guarantee timely completion of every external operation.

## 6. State Architecture

The actual schema is [state.py](devwatch/review/state.py), line 35.

All fields are declared through `TypedDict(total=False)`, so **none is statically required**. Several are operationally required once graph execution begins.

### ReviewState

| Field | Type | Written by | Read by | Purpose | Required? | Potential problem |
|---|---|---|---|---|---|---|
| `job_id` | `str` | `_invoke` | Checkpoint thread configuration is built from the same job ID | Job correlation | Operationally yes | Not consistently linked to public report and trace IDs |
| `target_path` | `str` | `_invoke` | Planner, renderer | Review target | Yes | Absolute repository paths can enter persistence/traces |
| `artifact_path` | `str` | `_invoke` | Dispatcher, verifier, gate | Snapshot location | Yes | Artifact integrity is not checked on resume |
| `artifact_files` | `List[str]` | `_invoke` | Planner normalization, dispatch | Available selected source | Yes | Does not encode actual review coverage or skip reasons |
| `artifact_hashes` | `Dict[str,str]` | `_invoke` | No integrity consumer found | Content identity | Intended | Stored but not enforced |
| `changed_regions` | `List[ChangedRegion]` | `_invoke` | Planner, task normalization | Changed-file/range scope | Yes for planning | Default specialist ignores these regions |
| `tool_evidence` | `List[ToolEvidence]` | `_invoke` | Planner, dispatcher, progress output | Command results | Optional | Raw output persisted; specialists ignore it |
| `review_tasks` | `List[ReviewTask]` | `plan_review` | Dispatcher, report metrics | Specialist assignments | Needed after planning | Task evidence duplicates global evidence |
| `candidate_findings` | Reducer-backed `List[CodeIssue]` | Initialization, specialists | Planner fallback, deduplication, metrics | Candidate collection | Needed | Truncated before deduplication; duplicate emissions are not idempotent |
| `failures` | Reducer-backed `List[dict]` | Planning, specialists, verification | Renderer | Partial-review evidence | Optional | Untyped, unbounded, and incomplete for silent failures |
| `deduped_findings` | `List[CodeIssue]` | Deduplication | Verification | Canonical candidates | Needed after deduplication | Objects can alias earlier candidate objects |
| `verified_findings` | `List[CodeIssue]` | Verification | Strict gate | Findings with decisions | Needed after verification | Missing decisions disappear without explicit disposition |
| `confirmed_findings` | `List[CodeIssue]` | Strict gate | Renderer | Accepted findings | Needed after gate | Acceptance defaults elsewhere weaken the contract |
| `manual_review_candidates` | `List[CodeIssue]` | Strict gate | Renderer | Escalated uncertainty | Optional | Only uncertain high/critical findings qualify |
| `report` | `ReviewReport` | Renderer | Graph caller/resume | Final result | Required on success | Duplicates findings and rendered summary |

### SpecialistState

| Field | Type | Written by | Read by | Purpose | Required? | Potential problem |
|---|---|---|---|---|---|---|
| `task` | `ReviewTask` | Dispatcher | Specialist node | Private assignment | Operationally yes | Context/task contracts remain dictionary based |
| `artifact_path` | `str` | Dispatcher | Specialist node | Source lookup | Yes | Mutable artifact risk |
| `artifact_files` | `List[str]` | Dispatcher | Not materially used by default specialist execution | Available paths | No | Redundant branch payload |
| `tool_evidence` | `List[ToolEvidence]` | Dispatcher | Passed into agent context | Evidence access | Optional | Default agent ignores it |
| `candidate_findings` | Reducer-backed list | Initialized by dispatcher; returned by branch | Parent graph reducer | Branch output | Optional initially | No emission identity |
| `failures` | Reducer-backed list | Initialized by dispatcher; returned by branch | Parent graph reducer | Branch failure output | Optional initially | Untyped records |

### Parallel safety

**The basic parallel-write design is correct.**

Specialists return updates to `candidate_findings` and `failures`, both of which have reducers. They do not simultaneously overwrite scalar report fields. There is no evidence that ordinary specialist branches overwrite each other’s results.

Remaining risks:

- `merge_candidates()` sorts and keeps the top 1,000 findings. It is deterministic for a fixed configuration, but not idempotent.
- Repeated candidates can consume capacity before deduplication.
- `merge_failures()` concatenates without a size limit or stable failure identity.
- Deduplication mutates `CodeIssue` objects retained from earlier state collections.
- Several copies of findings coexist in checkpoints.
- `TypedDict` does not provide runtime validation of the entire graph input.
- Raw LLM responses are not stored in graph state, which is appropriate. Finding descriptions, replacements, and tool output can still contain source or secrets.

### Current data/state flow

```mermaid
flowchart LR
    Prep["Preprocessing"] --> Meta["Artifact paths, hashes, changed regions, tool evidence"]
    Prep --> Static["Initial static candidates"]

    Meta --> Planner["review_tasks"]
    Planner --> Branch["Private SpecialistState per Send"]
    Branch --> Agent["Agent response validated as CodeIssue"]
    Agent --> Candidates["candidate_findings reducer"]
    Static --> Candidates

    Candidates --> Dedup["deduped_findings"]
    Dedup --> Decisions["verified_findings"]
    Decisions --> Gate["confirmed_findings + manual_review_candidates"]
    Gate --> Report["report"]
    Failures["failures reducer"] --> Report

    Meta -. checkpointed .-> SQLite["SQLite"]
    Candidates -. checkpointed .-> SQLite
    Decisions -. checkpointed .-> SQLite
    Report -. checkpointed .-> SQLite
```

**Recommended state direction:** retain immutable artifact references, typed coverage/task outcomes, finding records, verification decisions, failures, budgets, and report identity. Avoid persisting full evidence repeatedly inside every task. Use pure, idempotent reducers keyed by emission/task identity.

## 7. Component Inventory

| Component | Type | Purpose | Inputs → outputs | Dependencies | Current status | Recommendation |
|---|---|---|---|---|---|---|
| `cli.app` | Entry point | Local review | Path → report | Pipeline | Active | Align file/directory support |
| FastAPI server | Entry point | HTTP/WS application | Requests → responses | Routers/config | Active | Add real job lifecycle management |
| React review hook | Client controller | Upload, stream, cancel, display | Files/path → client report state | API service | Active | Fix production auth and capacity agreement |
| REST routers | Transport | Review, reports, filesystem | Pydantic/request input → JSON | Operations/auth/storage | Active | Standardize response contracts |
| WebSocket router | Transport | Stream review progress | JSON request → events/report | Operations/auth/storage | Active | Bound connections, handshake, queue |
| `ReviewOperations` | Application service | Validation and dispatch | Review request → report | Scanner/pipeline | Active | Centralize outcome and deadline policy |
| `ReviewPipeline` | Compatibility facade | Legacy API compatibility | Path/files → report | Engine/adapters | Active | Narrow compatibility responsibility |
| `ReviewEngine` | Orchestrator | Preprocess and execute graph | Review input → `ReviewReport` | Agents/tools/checkpointer | Active | Separate job preparation from graph execution |
| `RiskPlannerAgent` | LLM router | Select specialist tasks | File names/evidence summaries → tasks | Provider | Active | Guarantee deterministic minimum coverage |
| Four role reviewers | LLM specialists | Candidate detection | Assigned code → findings | Provider | Active | Bounded context and role-specific evidence |
| `StrictVerifierAgent` | LLM verifier | Decide candidate validity | File/candidates → decisions embedded in findings | Provider | Active | Strict required decision schema |
| Legacy planner/security/quality/verifier | Compatibility agents | Earlier review architecture | Legacy dictionaries → scope/findings | Legacy prompts/tools | Nondefault | Consolidate or deprecate deliberately |
| `ReportSynthesizerAgent` | Legacy LLM summarizer | Executive summary | Findings → report summary | Provider | Unused by default | Remove unused construction |
| `FakeAgent` / `FakeProvider` | Test doubles | Offline substitution | Canned input → output | None | Test support | Keep |
| Agent registry | Registry | Register agent instances | Agent ID → agent | BaseAgent | Not used by active orchestration | Remove or give a specific consumer |
| Scanner | Filesystem helper | Discover/read/tree | Path → files/content/tree | Filesystem/config | Active | Enforce one explicit workspace policy |
| Git collector | Parser/helper | Changed regions | Repository → regions | Git subprocess | Active | Apply limits to changed inputs first |
| Context selector/dependency mapper | Retrieval helper | Nearby dependencies/tests | Changed files → context paths | AST/regex/filesystem | Active | Connect selected context to prompts |
| Snapshotter | Artifact helper | Capture review input | Files → snapshot/artifacts | Filesystem | Active | Enforce immutability and hash checks |
| Command detector/runner | Execution helper | Test evidence | Manifests/argv → `ToolEvidence` | Host executables | Active, enabled by default | Isolate or disable |
| AST analyzer | Static analysis | Pattern candidates | Code → findings | Python AST/regex | Active | Separate detection from proof |
| Security/logic pattern tools | Static analysis | Legacy candidates | Code → findings | AST/regex | Legacy | Consolidate duplicated rules |
| Deduplicator | Aggregator | Combine candidates | Findings → canonical findings | Identity rules | Active | Preserve all provenance/evidence |
| Legacy verification strategies | Deterministic filters | Earlier acceptance policies | Findings/decisions → findings | Models | Nondefault | Avoid competing acceptance policies |
| Two chunkers | Context helpers | Split source | Code → chunks | AST/windowing | Not used in active path | Replace with one integrated strategy |
| Response cache | Cache | Isolated response reuse | Tenant/model/prompt/input → output | Memory | Not used in active path | Integrate only after correctness work |
| Models/state | Contracts | Type domain/graph data | JSON/dictionaries → models | Pydantic/TypedDict | Active | Require evidence and explicit decisions |
| Report renderer | Deterministic renderer | Final Markdown | Accepted/manual findings → text | `ReviewReport` | Active | Keep; add coverage/outcomes |
| Report storage | Persistence | Save/load reports | Report record → JSON file | Filesystem | Active | Retention, owner consistency, versioning |
| SQLite saver | Persistence | Graph checkpoint/resume | State → checkpoint | LangGraph/SQLite | Active | Migration/integrity/retention policy |
| LangSmith | External observability | Traces and experiments | Graph/model runs → hosted data | Environment/client | Integrated | Correlation and redaction |
| Evaluation script | Evaluation adapter | Dataset experiments | Dataset code → normalized report | LangSmith/engine | Present | Correct clean/partial semantics |
| External model services | External API | Generate plans/findings/decisions | Prompt → model response | Credentials/network | Configurable | Per-model capability validation |

There is **no active vector database, semantic repository index, autonomous tool loop, compiler service, or dedicated security-scanner service**.

## 8. Individual Agent Audits

Ratings are source-based engineering judgments, not measured agent-quality scores.

The rating order below is: **Architecture / Prompt / Tools / Output reliability / Responsibility isolation / Production readiness**.

### 8.1 RiskPlannerAgent — MODIFY

Source: [agents.py](devwatch/review/agents.py), line 44.

- **Purpose:** Route changed files to the smallest relevant specialist set.
- **Inputs:** File names, changed regions, tool evidence, initial static candidates, target path. The model prompt receives file names and tool summaries.
- **Outputs:** `List[ReviewTask]`, subsequently normalized and grouped by role.
- **Prompt:** Inline planning prompt; system role explicitly routes work and prohibits findings.
- **Model:** FAST tier.
- **Tools:** No model-callable tools. Deterministic fallback uses filenames and static security signals.
- **Dependencies:** Preprocessing and static analysis.
- **Downstream consumers:** `_plan_review()`, `_dispatch_tasks()`.
- **State reads:** Changed regions, target, tool evidence, candidates, artifact file list through its enclosing node.
- **State writes:** None directly; the node writes `review_tasks` and failures.
- **Failure behaviour:** Missing provider, model exceptions, or no usable model tasks produce fallback tasks. Node-level normalization failures produce a partial review with no specialist tasks.
- **Retry behaviour:** Shared bounded structured-output/provider retries; no graph node retry.
- **Validation:** Pydantic role/task validation and path intersection. No guaranteed coverage invariant on a successful partial model plan.

**Assessment:** Routing is separated from detection, but the LLM sees too little evidence to make informed risk decisions. Filename routing can miss authorization, concurrency, and performance logic in generically named files. Deterministic baseline coverage should remain mandatory; the model should only refine optional coverage.

**Ratings:** **6 / 5 / 4 / 5 / 8 / 4**.

### 8.2 Security RoleReviewAgent — MODIFY

Source: [RoleReviewAgent](devwatch/review/agents.py), line 162; security instructions at line 25.

- **Purpose:** Detect exploitable security defects and trust-boundary failures.
- **Inputs:** Assigned full source files, task focus; dependency context and tool evidence are supplied to `execute()` but ignored.
- **Outputs:** `List[CodeIssue]`.
- **Prompt:** Shared inline specialist prompt plus security-specific instructions and untrusted-source warning.
- **Model:** HEAVY tier.
- **Tools:** No model-callable tools and no security-specific tool integration.
- **Dependencies:** Planner task and prepared artifacts.
- **Downstream consumers:** Candidate reducer, deduplicator, verifier, gate.
- **State reads:** Task, artifact path, evidence through its enclosing node.
- **State writes:** Node returns candidate findings/failures.
- **Failure behaviour:** Exceptions become partial failures; unavailable provider or exhausted parsing can return an empty successful result.
- **Retry behaviour:** Shared bounded retry chain.
- **Validation:** Pydantic finding parsing, assigned-file filter, eventual evidence gate.

**Assessment:** The security responsibility is meaningful. The implementation lacks caller, authorization-policy, dataflow, and dependency context needed to establish exploitability. A cited `eval()` or SQL statement alone does not prove a vulnerability.

**Ratings:** **6 / 5 / 3 / 4 / 7 / 3**.

### 8.3 Architecture/API RoleReviewAgent — MODIFY

Source: architecture instructions in [agents.py](devwatch/review/agents.py), line 29.

- **Purpose:** Detect interface, contract, dependency-direction, lifecycle, and caller-breaking defects.
- **Inputs:** Assigned full files and focus; selected callers/dependencies are ignored.
- **Outputs:** `List[CodeIssue]`.
- **Prompt:** Shared specialist prompt plus architecture/API instructions.
- **Model:** HEAVY tier.
- **Tools:** None; no contract extraction or caller lookup.
- **Dependencies:** Planner and artifacts.
- **Downstream consumers:** Candidate reducer → deduplication → verification → gate.
- **State reads:** Private task/artifact state through the node.
- **State writes:** Candidate findings/failures through node updates.
- **Failure behaviour:** Same as the security role.
- **Retry behaviour:** Shared bounded retry chain.
- **Validation:** Same finding/path/evidence pipeline.

**Assessment:** This role is the most directly undermined by the context omission. The prompt asks it to find callers invalidated by a change while those callers usually never reach its prompt. Retain it conditionally for actual contract changes, backed by explicit caller and schema context.

**Ratings:** **5 / 5 / 2 / 3 / 6 / 3**.

### 8.4 Correctness RoleReviewAgent — MODIFY

Source: correctness instructions in [agents.py](devwatch/review/agents.py), line 33.

- **Purpose:** Detect concrete behavioral, state-transition, exception, boundary, and resource-management defects.
- **Inputs:** Assigned full source files and focus; tests and dependency context are ignored.
- **Outputs:** `List[CodeIssue]`.
- **Prompt:** Shared specialist prompt plus correctness/reliability instructions.
- **Model:** HEAVY tier.
- **Tools:** None; test outcomes are not consumed.
- **Dependencies:** Planner and prepared artifacts.
- **Downstream consumers:** Candidate reducer and final validation pipeline.
- **State reads:** Task/artifact state through the node.
- **State writes:** Candidates/failures through the node.
- **Failure behaviour:** Same silent-empty and exception distinction.
- **Retry behaviour:** Shared bounded retry chain.
- **Validation:** Pydantic parsing, path restriction, source gate.

**Assessment:** Appropriate as baseline coverage, but too broad for one potentially enormous role-wide prompt. Its reliability is weakened by missing tests, expected behavior, cross-file context, and explicit coverage reporting.

**Ratings:** **6 / 5 / 3 / 4 / 5 / 3**.

### 8.5 Performance/Concurrency RoleReviewAgent — MODIFY

Source: performance instructions in [agents.py](devwatch/review/agents.py), line 37.

- **Purpose:** Detect races, deadlocks, blocking async work, unbounded work, and query/allocation blowups.
- **Inputs:** Assigned full files and focus; runtime/dependency evidence is ignored.
- **Outputs:** `List[CodeIssue]`.
- **Prompt:** Shared specialist prompt plus performance/concurrency instructions.
- **Model:** HEAVY tier.
- **Tools:** None; no profiler, query-plan, load-test, or concurrency evidence.
- **Dependencies:** Planner and artifacts.
- **Downstream consumers:** Candidate reducer and validation pipeline.
- **State reads:** Private task/artifact state through the node.
- **State writes:** Candidates/failures through the node.
- **Failure behaviour:** Same as other role reviewers.
- **Retry behaviour:** Shared bounded retry chain.
- **Validation:** Shared Pydantic and evidence checks.

**Assessment:** Useful for source-visible async misuse and unbounded operations. It cannot reliably establish material performance impact, N+1 behavior across layers, or concurrency correctness without access patterns and callers. Run conditionally; require a concrete mechanism and impact explanation.

**Ratings:** **5 / 5 / 2 / 3 / 6 / 3**.

### 8.6 StrictVerifierAgent — MODIFY

Source: [agents.py](devwatch/review/agents.py), line 239.

- **Purpose:** Validate candidate claims against source evidence.
- **Inputs:** One full source file and candidate summaries containing ID, line, title, and claim.
- **Outputs:** Copies of existing findings with verification status, confidence, and rationale.
- **Prompt:** Inline strict-verifier instructions. It does not explicitly describe the full response schema.
- **Model:** FAST tier.
- **Tools:** None.
- **Dependencies:** Deduplication.
- **Downstream consumers:** `_verify()` and `strict_gate`.
- **State reads:** Deduplicated findings/artifact path through the node.
- **State writes:** Node writes verified findings/failures.
- **Failure behaviour:** Missing provider raises and marks verification partial. Exhausted parsing or missing decisions can instead return an empty result without failure.
- **Retry behaviour:** Shared bounded retry chain; files verified sequentially.
- **Validation:** Pydantic parsing; engine only accepts known IDs and copies three verification fields.

**Assessment:** Keeping verification separate is useful, and protecting original finding content is correct. Its current schema defaults are unsafe, its context is insufficient for cross-file claims, and same-provider/same-model verification is a correlated second opinion rather than independent proof.

**Ratings:** **7 / 4 / 3 / 4 / 8 / 3**.

### 8.7 Legacy PlannerAgent — MERGE

Source: [planner.py](devwatch/agents/planner.py).

- **Purpose:** Select priority files and focus areas.
- **Inputs:** Target path; scanner output and truncated Git diff.
- **Outputs:** `ReviewScope`.
- **Prompt:** Versioned `planner:v1` in `PromptRegistry`.
- **Model:** FAST tier.
- **Tools:** `CodebaseScanner`, `GitDiffTool`, invoked deterministically.
- **Dependencies:** None when called directly.
- **Downstream consumers:** Legacy planner adapter when injected into the facade.
- **State reads/writes:** No direct active graph state access; adapter converts scope into tasks.
- **Failure behaviour:** Deterministic limited-file fallback.
- **Retry behaviour:** Shared structured retry support.
- **Validation:** Pydantic planner response and scope.

**Assessment:** Duplicates routing responsibility and introduces a second contract. Its truncated scope can reduce coverage. Consolidate useful deterministic selection into the active planner; retain compatibility only where required.

**Ratings:** **4 / 5 / 5 / 4 / 6 / 3**.

### 8.8 Legacy SecurityAuditorAgent — MERGE

Source: [security.py](devwatch/agents/security.py).

- **Purpose:** Security review of a single file.
- **Inputs:** File path, source, focus.
- **Outputs:** `List[CodeIssue]`.
- **Prompt:** `security:v1` in the prompt registry.
- **Model:** HEAVY tier.
- **Tools:** Security patterns and AST analysis, invoked by code.
- **Dependencies:** Legacy scope/file dispatch.
- **Downstream consumers:** Legacy specialist adapter, active candidate pipeline when injected.
- **State reads/writes:** Adapter supplies file input and returns findings; no direct state access.
- **Failure behaviour:** Static detection remains useful without a model; propagated failures are handled by the adapter/node boundary.
- **Retry behaviour:** Shared structured retry chain.
- **Validation:** Structured security response mapped to `CodeIssue`.

**Assessment:** Useful static functionality overlaps the engine’s preprocessing and can duplicate candidates. Snippet redaction is helpful but does not protect full source sent to providers or descriptions.

**Ratings:** **5 / 6 / 5 / 4 / 6 / 3**.

### 8.9 Legacy QualityAuditorAgent — MERGE

Source: [quality.py](devwatch/agents/quality.py).

- **Purpose:** Single-file logic and quality review.
- **Inputs:** File path, source, focus.
- **Outputs:** `List[CodeIssue]`.
- **Prompt:** `quality:v1` in the registry.
- **Model:** HEAVY tier.
- **Tools:** Logic analyzer and AST analysis.
- **Dependencies:** Legacy scope/file dispatch.
- **Downstream consumers:** Legacy specialist adapter and candidate pipeline.
- **State reads/writes:** Adapter-mediated; no direct active-state mutation.
- **Failure behaviour:** Static checks can work offline; propagated errors can abort a legacy role batch.
- **Retry behaviour:** Shared structured retries.
- **Validation:** Structured quality response mapped to findings.

**Assessment:** Overlaps correctness, performance, and maintainability. Rules such as function length and debug printing need policy-specific treatment rather than the same severity/evidence semantics as concrete bugs.

**Ratings:** **4 / 5 / 5 / 4 / 4 / 3**.

### 8.10 Legacy VerificationAgent — REMOVE from the default architectural surface

Source: [verifier.py](devwatch/agents/verifier.py).

- **Purpose:** Filter candidate findings using legacy verification strategies.
- **Inputs:** File content and issues.
- **Outputs:** Filtered/mutated issues.
- **Prompt:** Registry verifier prompt.
- **Model:** FAST tier.
- **Tools:** `DefaultVerificationStrategy`, not a model-callable tool.
- **Dependencies:** Candidate production.
- **Downstream consumers:** Direct callers or injected facade verifier.
- **State reads/writes:** No direct state access.
- **Failure behaviour:** Missing model or missing verification data can preserve findings as-is.
- **Retry behaviour:** Shared structured retries.
- **Validation:** Legacy verification response; strategy allows missing decisions.

**Assessment:** Competes with the strict-verifier contract and does not consistently populate the confidence required by the active gate. Preserve only an explicit compatibility adapter if callers still depend on it.

**Ratings:** **3 / 6 / 4 / 2 / 7 / 2**.

### 8.11 ReportSynthesizerAgent — REMOVE unused runtime construction

Source: [synthesizer.py](devwatch/agents/synthesizer.py).

- **Purpose:** Generate an executive summary and report.
- **Inputs:** Findings and target path; model summary sees a limited subset.
- **Outputs:** Report summary/rendering.
- **Prompt:** Registry synthesizer prompt.
- **Model:** HEAVY tier.
- **Tools:** None.
- **Dependencies:** Findings.
- **Downstream consumers:** Direct legacy callers/tests; not the active graph.
- **State reads/writes:** None in the active graph.
- **Failure behaviour:** Deterministic fallback summary.
- **Retry behaviour:** Shared structured retries when invoked.
- **Validation:** Pydantic summary fields, but narrative deployment judgments are not evidence-validated.

**Assessment:** The default deterministic renderer already serves the current requirement. Creating an unused LLM summarizer obscures the real architecture. If narrative summaries are later needed, they should summarize an immutable accepted set and never decide findings.

**Ratings:** **3 / 5 / 5 / 4 / 5 / 2**.

### Per-agent assessment against the 20 requested questions

Abbreviations: **P** planner, **S** security, **A** architecture/API, **C** correctness, **PC** performance/concurrency, **V** strict verifier.

| Question | P | S | A | C | PC | V |
|---|---|---|---|---|---|---|
| 1. Responsibility clear? | Yes | Yes | Yes | Yes | Yes | Yes |
| 2. Too broad? | No | Some | Some | Yes | Some | No |
| 3. Overlap? | Legacy planner | C/A | C | S/A/PC | C | Legacy verifier |
| 4. Necessary as an LLM agent? | Unproven | Plausible | Conditional | Plausible | Conditional | Plausible |
| 5. Deterministic replacement for part? | Yes | Yes | Yes | Yes | Yes | Yes |
| 6. Too much context? | Usually no | Large batches | Large batches | Large batches | Large batches | Full files |
| 7. Too little context? | Source/risk | Trust/dataflow | Callers/contracts | Tests/behavior | Access/runtime | Dependencies/evidence |
| 8. Prompt matches role? | Mostly | Mostly | Mostly | Mostly | Mostly | Incomplete format |
| 9. Strict schema? | Structural | Structural | Structural | Structural | Structural | Defaults weaken it |
| 10. Output trusted directly? | No | No | No | No | No | No |
| 11. Unsupported claims possible? | Bad routes | Yes | Yes | Yes | Yes | Yes |
| 12. Duplicate work? | Legacy | Static/C | C | Other roles | C | Legacy |
| 13. Unnecessary tools? | No | No | No | No | No | No |
| 14. Missing useful tools/evidence? | Risk extraction | Security analysis | Caller lookup | Tests/types | Profiles/access | Reproduction/context |
| 15. Needs conversational memory? | No | No | No | No | No | No |
| 16. Needs retries? | Transient only | Bounded | Bounded | Bounded | Bounded | Bounded |
| 17. Lower temperature useful? | Yes | Evaluate | Evaluate | Evaluate | Evaluate | Yes |
| 18. Model appropriate? | Benchmark cheaper option | Quality critical | Benchmark | Quality critical | Benchmark | Quality critical |
| 19. Parallel execution? | Precedes roles | Yes | Yes | Yes | Yes | Per independent batch |
| 20. Conditional execution? | Optional LLM refinement | Yes | Yes | Baseline required | Yes | When candidates exist |

Legacy agents:

| Question | Planner | Security | Quality | Verification | Synthesizer |
|---|---|---|---|---|---|
| 1. Responsibility clear? | Yes | Yes | Some | Yes | Yes |
| 2. Too broad? | No | Some | Yes | No | Verdict authority |
| 3. Overlap? | Active planner | Active security/static | Correctness/performance | Strict verifier | Renderer |
| 4. Necessary separately? | No | No | No | No | No by default |
| 5. Deterministic part? | Yes | Yes | Yes | Yes | Yes |
| 6. Excess context? | Truncated listing | Full file | Full file | Full file | Repeated findings |
| 7. Missing context? | Source/coverage | Dependencies | Callers/tests | Dependencies | Omitted findings |
| 8. Prompt matches role? | Mostly | Mostly | Mostly | Mostly | Summary yes |
| 9. Strict schema? | Structural | Structural | Structural | Permissive | Structural |
| 10. Directly trusted? | No | No | No | No | No deployment verdict |
| 11. Hallucination risk? | Routing | Yes | Yes | Yes | Narrative |
| 12. Duplicates work? | Yes | Yes | Yes | Yes | Yes |
| 13. Unnecessary tools? | No | Duplicated rules | Duplicated rules | Competing strategy | No |
| 14. Missing useful context? | Coverage | Trust boundaries | Behavior | Evidence | Complete accepted set |
| 15. Needs memory? | No | No | No | No | No |
| 16. Needs retries? | Bounded | Bounded | Bounded | Bounded | Bounded if retained |
| 17. Lower temperature? | Yes | Evaluate | Evaluate | Yes | Evaluate |
| 18. Model justified? | Unproven | Quality critical | Benchmark | Quality critical | Heavy tier unproven |
| 19. Parallel? | Before review | Independent files | Independent files | Independent files | After findings |
| 20. Conditional? | Compatibility only | Compatibility only | Compatibility only | Compatibility only | Optional summary |

`FakeAgent` is a canned test double, not an AI reviewer. It records inputs and returns configured output; it has no prompt, model, tools, or retry behavior. **KEEP for testing.**

## 9. Agent Interaction Matrix

Communication is mediated by engine functions and state. Specialists do not communicate directly.

| Producer → consumer | Planner | Security | Architecture | Correctness | Performance | Verifier | Renderer |
|---|---|---|---|---|---|---|---|
| Planner | — | Task | Task | Task | Task | No | Task count |
| Security | No | — | No | No | No | Findings through dedup | Accepted findings |
| Architecture | No | No | — | No | No | Findings through dedup | Accepted findings |
| Correctness | No | No | No | — | No | Findings through dedup | Accepted findings |
| Performance | No | No | No | No | — | Findings through dedup | Accepted findings |
| Verifier | No | No | No | No | No | — | Decisions through gate |
| Static analyzer | Routing signal | No direct call | No | No | No | Candidates or bypass | Accepted findings |

“Accepted findings” means indirect consumption after the gate.

```mermaid
flowchart LR
    Engine["Engine / shared state"] --> Planner["RiskPlannerAgent"]
    Planner --> Tasks["Normalized tasks"]

    Tasks --> Security["Security"]
    Tasks --> Architecture["Architecture/API"]
    Tasks --> Correctness["Correctness"]
    Tasks --> Performance["Performance/concurrency"]

    Security --> Candidates["Candidate reducer"]
    Architecture --> Candidates
    Correctness --> Candidates
    Performance --> Candidates
    Static["Static candidates"] --> Candidates

    Candidates --> Dedup["Deterministic deduplication"]
    Dedup --> Verifier["StrictVerifierAgent"]
    Verifier --> Gate["Deterministic gate"]
    Gate --> Renderer["Deterministic renderer"]
```

The lack of peer dialogue is appropriate for independent review passes. Adding inter-agent conversation would increase complexity without addressing current evidence gaps.

## 10. Orchestrator Audit

`ReviewEngine` owns orchestration; `RiskPlannerAgent` supplies routing suggestions.

| Audit question | Finding |
|---|---|
| Agent selection | LLM plan or deterministic fallback |
| Assignment | File sets grouped into one task per role |
| All agents always run? | No |
| Execution order | Planner sequential; selected specialists parallel; verifier files sequential |
| Routing validation | Role enum, task schema, changed-file intersection |
| Routing failure | Planner model failure falls back; engine normalization failure records partial outcome |
| Coverage guarantee | No invariant ensuring every changed file receives baseline review after a successful partial plan |
| Loops | None |
| Termination | Finite graph; external work can still fail or outlive cancellation |
| Responsibility size | Engine combines too many job and graph concerns |
| Context passing | Loads selected context but default agents omit it |
| Direct communication | None |
| State isolation | Private task payloads and reducers are sensible |
| Observability | Plan is traceable, but fallback reasons/coverage are not explicit first-class records |
| Deterministic replacement | Baseline routing and coverage should be deterministic |
| Supervisor behavior | None; planner does not repeatedly inspect results and redirect agents |

**Scores:**

| Dimension | Score | Reason |
|---|---:|---|
| Routing quality | 4/10 | Filename-heavy and insufficient context |
| Determinism | 7/10 | Finite graph and normalized assignments |
| Failure handling | 4/10 | Explicit failures coexist with silent-empty outcomes |
| Scalability | 3/10 | Role-wide prompts and serial verification |
| Maintainability | 5/10 | Clear stages inside an oversized engine |
| Observability | 5/10 | Tracing exists, but coverage/outcome correlation is incomplete |
| Overall design | 5/10 | Sound workflow foundation, weak operational guarantees |

Keep deterministic graph orchestration. Make LLM routing advisory rather than authoritative over minimum coverage.

## 11. Tool Audit

**There are no active LLM function-calling tool schemas or `ToolNode` loops.** “Tools” here are helpers invoked by application code.

| Tool/helper | Users | Input → output | External dependency | Failure mode / assessment |
|---|---|---|---|---|
| `CodebaseScanner` | Engine, filesystem routes, legacy planner | Root/path → paths/content/tree | Filesystem | Validation/read failures; default workspace restriction is conditional |
| `GitChangeCollector` | Engine | Repository → `ChangedRegion[]` | Git | Git errors raise; nongit fallback is explicit |
| `GitDiffTool` | Legacy planner | Repository → diff string | GitPython/Git | Legacy, less precise than active collector |
| `ContextSelector` | Engine | Changed/available paths → context paths | Filesystem/parser | Approximate dependency/test selection |
| `DependencyMapper` | Context selector | Python source → import relationships | AST | Limited import resolution; not semantic dataflow |
| `WorkspaceSnapshotter` | Engine | Root/files → snapshot/artifacts | Filesystem | Copy/validation failures; snapshots remain writable |
| `detect_commands` | Engine | Snapshot manifests → `CommandSpec[]` | TOML/JSON parsing | Malformed config can be silently ignored |
| `RestrictedCommandRunner` | Engine | Snapshot + approved argv → `ToolEvidence` | Host tools/processes | Timeout bounded; execution not isolated |
| `ASTStaticAnalyzerTool` | Engine, legacy reviewers | File/source → `CodeIssue[]` | AST/regex | Syntax parsing errors can become no findings |
| `SecurityPatternTool` | Legacy security | File/source → findings | Regex | Heuristic false positives; no exploitability proof |
| `LogicAnalyzerTool` | Legacy quality | File/source → findings | AST/regex | Style and defect concerns mixed |
| `IssueDeduplicatorTool` | Engine | Findings → findings | None | Quadratic comparison; mutates objects; loses provenance |
| Secret snippet redaction | Legacy reviewers | Snippet → redacted snippet | Regex | Does not cover full prompts or all outputs |
| Two chunkers | Standalone/tests | Source → chunks | AST/windowing | Not used by active reviews |
| Response cache | Standalone/tests | Identity/input → cached response | Memory | Not used by active reviews; mutable cached objects |

### Command safety

The runner has useful controls:

- `shell=False`.
- Exact command/working-directory allowlist.
- Restricted executable names.
- Rejection of direct shell syntax, installation commands, inline Python, and traversal arguments.
- Bounded captured output.
- Timeout with process-tree termination.

These controls **do not isolate repository code**.

`python -m pytest` imports repository tests and plugins. `npm test` runs repository-controlled scripts and lifecycle hooks. That code can access host files, use the network, spawn processes, and consume resources regardless of the outer argv restrictions.

The command list is partly derived from the repository itself. It is therefore not an independent trust policy.

**Recommendation:** disable repository execution by default until an OS-enforced worker sandbox exists. Run tests in a separate disposable environment with controlled dependencies, no host credentials, constrained filesystem/network access, resource limits, and cancellation-aware process supervision.

Also connect useful, sanitized tool evidence to specialist and verifier inputs. Currently most command output only affects the planner through an exit-code summary.

## 12. Prompt Audit

Active prompts are inline in [review/agents.py](devwatch/review/agents.py). Legacy prompts use [registry.py](devwatch/prompts/registry.py).

| Concern | Current assessment |
|---|---|
| Role clarity | Good at a high level |
| Task boundaries | Defined by role, but substantial overlap remains |
| Output format | Specialist and planner show JSON examples; verifier lacks an explicit complete format |
| Schema enforcement | Local parsing after generation; provider-native schema not sent |
| Evidence requirement | Concrete source support requested |
| Exact citation | Line-numbered source, but exact range/snippet relationship is under-specified |
| Severity definitions | Insufficiently explicit in active prompts |
| Confidence calibration | Scores requested without calibration rubric |
| Clean-code behavior | Empty issue list is possible, but failure and clean outcomes are indistinguishable |
| Duplicate prevention | Handled primarily downstream |
| Escalation | Verifier prompt does not adequately specify uncertainty and missing-context behavior |
| Untrusted source | Explicit system warning and source delimiters |
| Tool guidance | No autonomous tools; relevant prepared evidence is missing |
| Versioning | Active metadata contains prompt IDs, but active prompts bypass the registry |

The prompts are not inherently too verbose. **Source payloads are the oversized part.**

Specific changes:

1. Require original-source start/end lines and an exact cited range.
2. Define severity by concrete impact and reachability.
3. Require the failure mechanism, trigger, and expected versus actual behavior.
4. Include changed regions, bounded caller/dependency context, and sanitized relevant tool evidence.
5. Give each role an exclusion boundary to reduce repeated reasoning.
6. Require explicit uncertainty when necessary context is absent.
7. Supply the actual response schema.
8. Version the active prompt text, not only metadata labels.
9. Require verifier decisions for every input ID, with no implicit acceptance.
10. Treat filenames, comments, tool output, and planner focus as untrusted content.

The shared specialist prompt interpolates filenames into source tags without escaping. Delimiters help readability but are not a security boundary against malicious source or filenames.

Temperature is requested as `0.2`, but the Gemini adapter omits the temperature option. The effective Gemini setting therefore comes from provider defaults.

## 13. Output Schema Audit

Pydantic is the main runtime contract. TypedDict describes graph state. Agent contexts, metrics, metadata, evidence, and failures still use arbitrary dictionaries.

### Current schema strengths

- Standard `CodeIssue` domain model across active roles.
- Enumerated severity and verification status.
- Confidence ranges.
- Validated changed-region ranges.
- Structured planning and specialist-response models.
- Engine-side protection against verifier additions and content rewriting.

### Important weaknesses

Source: [models.py](devwatch/models.py), line 49.

- Finding locations and snippets are optional.
- No finding-level schema validator guarantees positive, ordered ranges.
- Invalid severity strings silently become `MEDIUM`.
- Candidate verification status defaults to `ACCEPTED`.
- Some confidence defaults are optimistic.
- Source type and evidence dictionaries are loosely typed.
- Extra response fields are not explicitly forbidden.
- `{}` validates as an empty specialist response.

The most serious verification weakness is `VerificationItem` in [models.py](devwatch/models.py), line 170:

- `status` defaults to `ACCEPTED`.
- `is_true_positive` defaults to `True`.
- `confidence` defaults to `0.9`.
- `reasoning` defaults to an empty string.

Thus a response containing only a valid `finding_id` can become a positive high-confidence decision.

`VerificationDecision` in `review/models.py` already provides a stricter direction, but it is not the active provider-response contract.

### Recommended contract

Keep one canonical finding model, with separate lifecycle records:

| Record | Required information |
|---|---|
| Candidate | Server-assigned ID, role/task provenance, snapshot ID, path/range, claim, severity, exact evidence reference |
| Verification decision | Candidate ID, explicit status, explicit confidence, nonempty rationale, evidence/reproduction references |
| Disposition | Confirmed, rejected, uncertain, invalid evidence, missing decision, budget-skipped, duplicate, or failed |
| Review outcome | Complete, partial, failed, cancelled, or no applicable changes |
| Coverage | Requested/discovered/reviewed/skipped files and reasons |

Initial candidates should be **unverified**, not accepted.

Finding IDs should distinguish occurrences within a snapshot while allowing a separate cross-review similarity key. Current IDs omit source location and snapshot identity, allowing identical snippets at different locations to share IDs.

Frontend contracts also need alignment: backend `reproduction` is a dictionary while frontend typing expects a string, and report count fields differ between response paths.

## 14. Aggregator / Final Reviewer Audit

The active final reviewer is a pipeline:

`candidate reducer → deduplicate → verify → strict_gate → render_report`.

### What it does correctly

- Receives collected specialist and static candidates, subject to the candidate cap.
- Sorts output deterministically.
- Preserves stronger severity during duplicate merging.
- Restricts verifier outputs to known candidate IDs.
- Copies only verification status, confidence, and rationale from verifier results.
- Prevents the verifier from inventing a new finding or silently changing severity.
- Uses a deterministic final renderer.

### Where valid findings can disappear

1. Candidate cap before deduplication.
2. Deduplication identity collisions.
3. Missing verifier decisions.
4. Structured-output failure returned as an empty list.
5. Evidence fingerprint mismatch.
6. Accepted decisions below the confidence threshold.
7. Nonconclusive static findings rejected by the gate.
8. Uncertainty on medium/low findings suppressed rather than retained.

### Static evidence contradiction

In the strict evidence check in [engine.py](devwatch/review/engine.py), line 647, a static finding is valid only when its evidence has `conclusive=True`.

Nonconclusive static candidates can undergo LLM verification, but the engine preserves their original source type and evidence. Consequently, **they still cannot pass the final gate after positive verification**.

Conversely, a title allowlist in `_static_findings()` in [engine.py](devwatch/review/engine.py), line 808, assigns confidence `1.0` and bypasses model verification for several heuristics.

An `eval()` call is evidence that `eval()` is present. It is not automatically evidence of attacker-controlled execution. Broad/bare exception handling likewise requires behavioral context.

### Deduplication

The implementation uses identity, normalized paths, rule/CWE, fingerprints, and line proximity.

Problems:

- Agent provenance is merged as `source_type`; multiple specialist sources often collapse to `"agent"`.
- Losing candidates’ evidence and rationales are not fully preserved.
- Same-root-cause findings under different rule/category IDs may remain duplicated.
- Identical distant occurrences may retain the same finding ID and collide later.
- Merging mutates original finding objects.
- Complexity is approximately quadratic in retained candidates.

**Recommendation:** deterministic identity/root-cause grouping first. Preserve all supporting observations and agent identities. An optional semantic similarity stage may suggest merges, but should not delete evidence or decide severity independently.

### Aggregator scores

| Dimension | Score |
|---|---:|
| Determinism | 8/10 |
| Evidence validation | 4/10 |
| Preservation of valid findings | 3/10 |
| Prevention of invented findings | 7/10 |
| Provenance preservation | 3/10 |
| Overall | 5/10 |

Keep the deterministic renderer and staged validation. Fix lifecycle and evidence semantics before adding another reviewer agent.

## 15. Routing & Parallelism Audit

| Agent/node | Current execution | Recommended execution | Reason |
|---|---|---|---|
| Preprocessing | Before graph; some synchronous work | Bounded preparation worker | Avoid event-loop blocking and unify deadlines |
| Command evidence | Sequential commands | Isolated bounded execution | Safety and cancellation matter before speed |
| Static analysis | Sequential changed-file entries | Unique files; bounded concurrency if useful | Multiple hunks currently repeat whole-file analysis |
| Planner | One sequential logical call | Deterministic baseline, optional LLM refinement | Coverage must not depend on model routing |
| Security | Conditional parallel role task | Conditional parallel bounded batches | Independent of other specialists |
| Architecture/API | Conditional parallel role task | Conditional parallel bounded batches | Needs actual contract/caller context |
| Correctness | Parallel when selected | Required baseline batches | Every supported executable change needs coverage |
| Performance/concurrency | Conditional parallel role task | Conditional parallel bounded batches | Independent, risk-triggered |
| Deduplication | After fan-in | Keep deterministic fan-in | Needs all candidate observations |
| Verification | Sequential per file | Bounded parallel verification batches | Independent files need not wait for each other |
| Strict gate | Sequential deterministic | Keep | Cheap consistency check |
| Rendering | Sequential deterministic | Keep | No benefit from another model stage |

Concurrency has several layers:

- Per-engine LLM semaphore.
- Global resilience semaphore.
- Provider semaphore, default concurrency **2**.
- Up to four role tasks in the active plan.

Therefore, graph fan-out does not imply four simultaneous provider requests under default adapter settings.

The existing specialist parallelism is directionally correct. The bottleneck is large task granularity and serial verification—not absence of parallel agents.

## 16. Context Management Audit

| Consumer | Actual model context |
|---|---|
| Planner | Filenames and command summaries |
| Specialist | Assigned full source files and focus |
| Verifier | One full source file and candidate summaries |
| Renderer | Confirmed/manual findings |
| Legacy agents | Mostly single-file source, selected focus, limited diff/listing |

The engine selects immediate imports, matching tests, and some dependents. It passes them as `context_files`, but `RoleReviewAgent.execute()` never incorporates them.

The same omission applies to:

- `task.changed_regions`.
- `task.evidence`.
- Global `tool_evidence`.

This makes the current review effectively a set of **full-file specialist prompts**, despite more sophisticated context preparation around them.

Other findings:

- No active token-aware chunking.
- No active semantic retrieval or repository index.
- No active cache.
- Repeated source is sent across specialist roles and again to verification.
- One task per role can include many files.
- `MAX_TOKENS_PER_AGENT` is not an effective prompt limit.
- Provider capability context limits are advertised but not enforced.
- Existing chunkers are not integrated and should not be wired in blindly; line mapping and omitted globals/decorators need attention.

**RAG is not the first required fix.** Start with deterministic dependency/caller/test retrieval and bounded source packets. A semantic index becomes useful when evaluating larger repositories shows that deterministic retrieval misses necessary context.

### Code-review capability assessment

| Defect class | Current reliability |
|---|---|
| Simple source-local suspicious patterns | Strongest current capability, although heuristic severity can be wrong |
| Syntax problems | Not reliable; AST parse failure can be silently ignored |
| Local branch/boundary bugs | Partial; depends on model reasoning and gate survival |
| Runtime failures | Partial; command results are poorly integrated |
| Type errors | Not reliable without actual type-checker evidence |
| Security injection | Partial; constructs detected, exploitability/dataflow weak |
| Authorization problems | Weak without policy and caller context |
| Concurrency/races | Partial for obvious source-local cases |
| Bad async usage | Partial; model can identify blocking operations |
| N+1 queries | Weak without call/access patterns |
| Memory/resource leaks | Partial for local lifetime mistakes |
| API/architecture defects | Weak across files because caller context is omitted |
| Maintainability/duplicate code | Some legacy heuristics; not comprehensive or policy-driven |
| Dependency misuse | Weak without dependency versions/contracts |

No current evidence supports claiming comprehensive coverage of these classes.

## 17. Reliability & Error Handling

| Failure | Current behavior | Recommended behavior |
|---|---|---|
| Specialist raises | Failure recorded; other branches survive | Keep, with task coverage marked failed |
| Provider unavailable during specialist review | Empty findings | Explicit unavailable/partial outcome |
| Structured parsing exhausted | Wrapper returns `None`; often becomes empty output | Typed failure, never clean |
| Planner model fails | Deterministic fallback | Keep; record fallback reason |
| Planner normalization fails | No tasks and planning failure | Preserve minimum deterministic coverage where possible |
| Verifier raises | Per-file failure; other files survive | Keep, retain unresolved candidates |
| Verifier omits IDs | Omitted findings disappear | Explicit missing-decision dispositions |
| Provider timeout/transient error | Bounded retries | One deadline-aware retry owner |
| Authentication/quota/context error | Generally nonretryable | Keep classification; expose truthful outcome |
| Command nonzero exit | Stored as evidence | Parse relevant failure evidence |
| Command validation/start failure | Can fail preprocessing/review | Typed tool outcome and partial policy |
| AST syntax error | Can become no findings | Emit syntax diagnostic or unsupported outcome |
| Deduplication/rendering failure | Unhandled graph failure | Fail clearly; retain checkpoint and correlation |
| Client disconnect | WS tasks cancelled | Also terminate worker/process work |
| Missing/corrupt saved report | Often appears as not found | Distinguish absence from corruption operationally |

### Retry design

The system has multiple nested retry layers:

1. Structured-output loop: up to **3 generation attempts**.
2. Resilience manager: up to **3 provider attempts** per generation.
3. Installed OpenAI SDK default: **2 retries**, or up to **3 HTTP attempts**, unless overridden.

A logical structured call can therefore involve a potential **27 HTTP attempts** across combined failure modes, although deadlines, exception types, and circuit breaking can stop it earlier.

There is no infinite retry loop. The problem is multiplication, cost, and latency.

Additional reliability issues:

- Backoff sleeps while holding the resilience semaphore.
- Half-open circuit probes can remain marked in flight after cancellation or a nonretryable exception.
- Circuit-breaker environment values are bypassed by truthy constructor defaults.
- Token limits are checked after responses, not reserved before calls.
- Overspending responses can raise before usage is recorded.
- Job token records have no active cleanup call.
- New HTTP/model clients are constructed per request without an explicit close lifecycle.
- Repository reviews have the facade’s global deadline; uploaded reviews and direct engine/evaluation paths do not share it.
- Cancelling `asyncio.to_thread()` does not immediately stop the underlying command process.
- Server shutdown task tracking is not populated by actual review routes.
- Resume does not verify artifact hashes or graph/prompt versions.

The graph degrades gracefully for some exceptions, but not consistently for missing or malformed results.

## 18. Security Audit

These are source-grounded risks. Actual remote exposure, deployment isolation, credentials, and exploitability were not tested.

| Boundary | Finding | Risk |
|---|---|---|
| Repository → host process | Default-enabled pytest/npm execution without OS sandbox | Host compromise from malicious reviewed code |
| Request → filesystem | Workspace restriction is conditional on explicit/custom configuration | Arbitrary root access if exposed with permissive defaults |
| Source → model | Source sent to external provider; prompt warning is not enforcement | Prompt injection and source/secret disclosure |
| Source → tracing | Wrapped model prompts can include full source | Additional external data destination |
| Source → artifacts/checkpoints | Persistent findings, replacements, command output | Sensitive data retention |
| REST/WS → principal | Different identity formats | Broken report ownership |
| Browser → production API | Frontend supplies no auth; browser WS cannot set arbitrary headers | Production flow fails |
| Filesystem tree → symlinks | Tree traversal lacks the scanner’s equivalent symlink protection | Possible out-of-root enumeration |
| Upload → memory | Whole request received before complete aggregate validation | Memory/resource exhaustion |
| Client → progress queue | Unbounded queue and steps collection | Backpressure/resource exhaustion |
| Process → credentials | Environment denylist, host home/PATH retained | Filesystem credentials remain accessible |
| Snapshot → resume | Writable artifacts and unused hashes | Review integrity drift |

### Authentication findings

In [auth.py](devwatch/auth.py):

- REST returns `user:<key-prefix>...`.
- WebSocket returns `ws-user:<key-prefix>`.
- Production report access compares owner strings exactly.

The same key therefore does not produce the same principal across transports.

Development mode also allows requests with **no key even when a development key is configured**. This is acceptable only as an intentional, locally bound development policy; it is not an authentication guarantee.

The WebSocket authentication docstring mentions a first-message handshake, but implementation authenticates headers before acceptance. The frontend sends no such headers.

Use a consistent principal representation and a browser-compatible authentication design—such as a secure same-origin session or scoped WebSocket ticket. Avoid embedding long-lived API keys in URLs.

### Prompt injection

Positive controls:

- Source is marked untrusted.
- Specialists cannot directly execute tools.
- Output paths are restricted.
- The gate checks cited source.

Remaining limitations:

- Repository comments and filenames can still influence model output.
- Planner focus and command output are not trustworthy instructions.
- A source fingerprint proves correspondence to text, not the truth of a claim.
- Correct-looking JSON can still contain malicious or unsupported reasoning.

### Secrets

I did not inspect `.env` or secret values. `.env` is not tracked in the inspected Git index, but that does not prove the absence of secrets elsewhere.

Secret filename blocking and snippet redaction are incomplete across upload, provider, logging, tracing, report, and checkpoint paths. A complete source-handling policy must cover all destinations.

## 19. Observability / LangSmith Audit

LangSmith is already integrated. The provider wraps OpenAI-compatible clients with `wrap_openai`; that wrapper supports automatic model tracing when tracing is configured. [LangSmith OpenAI tracing](https://docs.langchain.com/langsmith/trace-openai)

The audit did not access the live LangSmith project, so actual trace completeness cannot be certified.

| Signal | Current source support |
|---|---|
| Graph nodes | LangGraph can expose them |
| Planner decisions | Tasks appear in node output |
| Model inputs/outputs | Wrapped calls |
| Token usage | Provider response and progress usage tracking |
| Errors | Model/graph errors plus logs |
| Latency | Model timing and progress timing |
| Specialist identity | Role data exists, but graph node name is shared |
| Tool calls | Progress events; preprocessing helpers lack dedicated trace spans |
| Retries | Logs and nested calls; no unified attempt record |
| Final output | Graph report |
| Coverage | Not adequately represented |
| Report/job/trace correlation | Incomplete |

Current limitations:

- Preprocessing is outside the graph and outside its elapsed-time origin.
- All specialists share the `run_specialist` node name.
- Active prompt versions are not reliably attached to traces.
- Command output can be emitted in progress `tool_results`.
- Audit creation logs do not consistently use the actual saved report ID.
- Token accounting is not a durable complete job ledger.
- Live tracing configuration and UI-configured evaluators cannot be determined from source alone.

Recommended metadata:

`job_id`, `report_id`, `trace_id`, `task_id`, `agent_name`, `specialist_role`, `graph_version`, `prompt_version`, `model`, `provider`, `language`, `review_mode`, `snapshot_hash`, `coverage_status`, and a redacted repository identifier.

Trace retries, preparation, context selection, tool outcomes, and suppression dispositions separately. Apply redaction before external tracing.

## 20. Evaluation Readiness

Evaluation is **present but incomplete**, not absent.

[evaluate_langsmith.py](evaluate_langsmith.py) runs a LangSmith dataset target against uploaded Python/JavaScript code.

Limitations:

- Dataset inputs become generic single-file names.
- Repository-level routing signals and cross-file behavior are not represented.
- The target bypasses the facade’s repository deadline.
- `clean` means no confirmed issues and no manual candidates; it ignores partial/failure/coverage status.
- No local evaluator list is supplied. Dataset/UI evaluator configuration cannot be verified here.
- Normalization loses some provenance and lifecycle information.
- Concurrency is deliberately `1`, so the experiment does not assess load behavior.

### Historical results

From the supplied local evaluation CSV exports, [summary](langsmith_evaluation_summary.csv) and [diagnostics](langsmith_evaluation_diagnostics.csv):

| Metric | Historical value |
|---|---:|
| Examples | 28 |
| Expected buggy | 22 |
| Expected clean | 6 |
| Buggy examples detected | 6 |
| Missed buggy examples | 16 |
| Clean examples classified clean | 6 |
| Example-level false positives | 0 |
| Example-level precision | 100% |
| Example-level recall | 27.3% |
| Example-level F1 | 42.9% |
| Judge passes | 12/28 |
| Misses with no candidates | 8 |
| Misses with candidates subsequently suppressed | 8 |

**The precision figure is example-level classification precision, not proof that each reported finding was correct.** The six clean examples are too few to establish a robust false-positive rate.

### Independent evaluation targets

| Level | Evaluate |
|---|---|
| System | Finding precision/recall, severity accuracy, truthful coverage, partial outcomes |
| Planner | Required-role recall, baseline coverage, unnecessary-role rate |
| Security | Exploitability precision, authorization/injection recall, unsupported-claim rate |
| Correctness | Behavior-grounded bug recall and reproduction success |
| Performance | Mechanism validity, impact support, concurrency defect recall |
| Architecture/API | Contract/caller defect recall with cross-file fixtures |
| Verifier | False rejection, false acceptance, decision completeness, calibration |
| Tools | Path safety, diagnostic accuracy, cancellation, output limits |
| Deduplication | Duplicate reduction, distinct-issue preservation, provenance retention |
| Trajectory | Stage completion, retry multiplication, budget/deadline compliance |
| Report | Finding preservation, location accuracy, outcome/coverage honesty |

Evaluate candidate generation and suppression separately. Otherwise a low final recall cannot be attributed to routing, detection, verification, or the gate.

## 21. Scalability Audit

| Repository/input size | Actual likely behavior |
|---|---|
| 1 file | Manageable prompt size, but verification/evidence defects still apply |
| 10 files | Role batching may work; repeated context and serial verification become noticeable |
| 100 files | Discovery capacity reached; potentially very large role prompts |
| 1,000+ files | Default repository discovery still stops near 100 eligible files; uploaded batches are also limited |
| Very large changed file | May be skipped by scanner size limits without adequate coverage reporting |

The most serious scaling defect is ordering:

1. Discover up to the configured file limit.
2. Collect Git changes.
3. Intersect changes with discovered files.

A changed file outside that initial discovery set is omitted. The engine can then say no reviewable Git changes were found.

Other bottlenecks:

- Git untracked-file line counting reads eligible untracked files before final scanner intersection and limits.
- Scanner/dependency/Git preparation includes synchronous work in async paths.
- Role tasks are merged into large batches.
- Verification is sequential.
- Snapshot creation can copy more files for commands than are reviewed.
- Full source exists in memory alongside prompts and artifacts.
- Candidate sorting serializes findings repeatedly.
- SQLite, report storage, rate limiting, and provider limits are local-process/local-filesystem designs.
- Artifact pruning does not coordinate with active jobs.
- Checkpoints and reports lack matching retention cleanup.

The large-repository test does not establish complete review of thousands of files: discovery remains independently capped, and its assertions do not require all files to receive review coverage.

**Recommendation:** select changed targets first, record every skip, batch within token budgets, and introduce a bounded job queue before increasing file limits.

## 22. Performance Audit

| Component | Cost source | Latency risk | Improvement |
|---|---|---|---|
| Discovery/Git/context | Directory traversal, subprocesses, parsing | Event-loop blocking and unbounded untracked reads | Bounded preparation outside event loop |
| Snapshot | Read/copy/hash files | Expanded snapshots | Separate review artifacts from execution workspace |
| Commands | Tests/scripts | Potentially several 120-second commands | Isolated deadline-aware execution |
| Planner | One model generation plus retries | Additional serial stage | Deterministic baseline; optional inexpensive refinement |
| Specialists | Full-file role batches | Context size and provider concurrency | Bounded batches and selective context |
| Deduplication | Pairwise comparisons | Approximately quadratic | Indexed identity/group matching |
| Verification | One logical call per candidate-bearing file | Sequential latency accumulation | Bounded parallel batches |
| Checkpointing | Serialized state writes | Repeated large finding/evidence collections | Smaller state/reference records |
| Provider setup | New client per request, request delay | Connection churn and repeated delay | Managed reusable client lifecycle |
| Rendering | String formatting | Low | Keep deterministic |

Approximate current critical path:

`preparation + commands + planner + specialist makespan + sum(file verification times) + checkpoint/render overhead`.

The historical export reports mean example latency of approximately **21.48 seconds**. That is not a benchmark for repository review, concurrency, or this exact revision.

Caching may help stable parser outputs, context packets, and repeated verification against the same immutable snapshot. The standalone cache does not currently provide those benefits.

## 23. Cost Audit

For a successful active review with a configured provider:

`logical model calls = 1 + S + V`

Where:

- `1` is planning.
- `S` is selected specialist roles, normally 1–4.
- `V` is the number of files requiring nonconclusive model verification.

| Scenario | Calls before retries |
|---|---:|
| Clean Git repository | 0 |
| Provider unavailable | 0 model calls; outcome semantics need correction |
| One specialist, no model-verifiable candidates | 2 |
| One file, 1–4 specialists, verification needed | 3–6 |
| 10 files, 2–4 roles, 3–10 verification files | 6–15, illustrative |
| 100 files, all roles, verification for each | Up to 105 logical calls |

These are source-derived bounds/scenarios, not observed averages.

Retries can multiply model/HTTP attempts. Actual worst-case spending is affected by deadlines, provider errors, SDK behavior, and circuit breaking; the token budget is not a hard preflight cap.

Historical exported totals:

- **70,122 tokens**.
- **$0.04899375** recorded cost.
- Approximately **$0.00175 per example**.

These figures should not be extrapolated to larger reviews or another model configuration.

Both FAST and HEAVY default to `gemini-3.7-flash`; the tier labels do not currently imply different models. Google documents a large context window and structured-output support for that model, but provider capabilities still need to be checked and used per configured model. [Gemini 3.7 Flash model documentation](https://ai.google.dev/gemini-api/docs/models/gemini-3.7-flash)

Cost priorities:

1. Remove unnecessary planner calls where deterministic routing is sufficient.
2. Reduce duplicated source context.
3. Consolidate retry ownership.
4. Reserve token/output budgets before dispatch.
5. Use smaller routing models only after routing coverage tests.
6. Preserve model quality for security detection and verification until evaluations justify changes.

## 24. Testability Audit

The architecture is reasonably testable in isolation:

- Agents/providers can be injected.
- Fake agents/providers support offline tests.
- Graph routing, evidence checks, cancellation, checkpointing, and transport behavior have tests.
- The deterministic renderer and deduplicator are independently testable.
- Frontend report, stream, cancellation, source-navigation, and activity tests exist.

However, test presence does not establish current passing status. **No fresh tests were run during this audit.**

Important gaps and misleading coverage:

- Acceptance fixtures largely exercise deterministic AST findings, not real specialist quality.
- Some tests intentionally treat harmless `eval('1+1')` as a critical finding.
- The large-repository test checks bounded output/time/memory, not complete coverage.
- Shutdown tests manually register tasks rather than proving routes register them.
- WS authentication tests use clients that can set headers, unlike the browser implementation.
- Report ownership tests do not cover WS creation followed by REST retrieval.
- Chunker/cache tests do not prove production integration.
- Missing decisions, empty parsing results, and uncovered files need explicit outcome assertions.

Recommended structure:

| Layer | Tests |
|---|---|
| Contracts | Required fields, malformed responses, invalid locations, duplicate IDs |
| Reducers | Order independence, idempotence, caps, immutable inputs |
| Tools | Path limits, syntax errors, command policy, cancellation, resource bounds |
| Agents | Captured prompt context and typed failure outcomes |
| Graph | Fan-out/fan-in, baseline coverage, partial branches, suppression dispositions |
| Persistence | Artifact integrity, resume, version mismatch, retention |
| Transports | Same-principal ownership, browser-compatible auth, deadlines, request limits |
| Quality evaluation | Realistic cross-file bugs and clean counterexamples |
| Load | Queue saturation, concurrent cancellation, SQLite/storage pressure |
| Frontend | Upload/backend limit agreement and source revision consistency |

Active prompts should become versionable fixtures. Avoid using fake-model orchestration tests as evidence of real model precision/recall.

## 25. Multi-Agent Architecture Justification

The current design has a plausible reason for multiple review passes: security, behavior, contracts, and concurrency benefit from different attention patterns.

That benefit is **not demonstrated by current evidence**. The roles share models, source payloads, schemas, and implementation; specialization is mostly prompt-level.

| Alternative | Quality potential | Latency/cost | Complexity/debugging | Assessment |
|---|---|---|---|---|
| Single powerful reviewer | Strong baseline | Few calls | Simple | Must be benchmarked |
| Single reviewer + deterministic tools | Strong evidence foundation | Usually efficient | Manageable | Essential comparator |
| Router + specialists | Selective attention | Routing overhead | Route misses complicate diagnosis | Current direction, needs coverage guarantees |
| Parallel specialists + deterministic aggregator | Independent viewpoints | More tokens, lower specialist latency | Clear stage boundaries | Closest useful target |
| Supervisor multi-agent loop | Adaptive investigation | Unpredictable calls/latency | Highest complexity | Not justified by present requirements |
| Current workflow | Plausible specialization | Extra verification and repeated context | Inspectable graph | Evidence gaps negate much of the benefit |

Overlap exists:

- Security and correctness both detect missing validation and resource failures.
- Architecture/API and correctness both detect broken caller contracts.
- Performance/concurrency and correctness both detect races and lifecycle defects.
- Legacy quality overlaps all three nonsecurity roles.
- Static analysis duplicates some model detection.

Do not add more agents now. Evaluate:

1. Single reviewer + tools.
2. Correctness plus conditional security.
3. All current roles with repaired context.
4. The same variants with and without model verification.

Compare finding-level precision/recall, latency, cost, and failure outcomes on identical snapshots.

## 26. Critical Problems

“Critical” here means a production blocker, not an asserted CVSS classification.

### CRITICAL

| ID / problem | Why it matters and risk | Location | Recommended fix |
|---|---|---|---|
| C1. Host execution of repository code | Untrusted tests/scripts can access host files/network; deployment isolation unknown | [runner.py](devwatch/review/runner.py), line 289; `detect_commands`, config | Disable by default; isolated execution worker |
| C2. Incomplete reviews can appear clean | Empty provider/parsing outputs and missing coverage undermine result meaning | Role/verifier agents, renderer, evaluation normalization | Typed outcomes and coverage; fail explicitly |
| C3. File cap precedes changed-file selection | Changed targets can disappear and produce “no changes” | [scanner.py](devwatch/scanner.py), line 165; [engine.py](devwatch/review/engine.py), line 121 | Select changes first; explicit skipped manifest |
| C4. Static verification contradiction | Nonconclusive candidates always fail; selected heuristics auto-pass | `_static_findings`, `_verify`, `_has_valid_evidence` | Separate evidence existence from proof; coherent decision path |
| C5. Permissive verification defaults | ID-only decisions can accept with confidence `0.9` | [models.py](devwatch/models.py), line 170 | Require status/confidence/rationale; reconcile all IDs |
| C6. Production transport authentication broken | Browser cannot authenticate as implemented; WS owners differ from REST | `auth.py`, `routers/ws.py`, frontend API | One principal and browser-compatible auth |
| C7. Missing common admission/deadline policy | Uploaded jobs, connections, queues and preparation can exceed intended limits | Facade, WS router, config/server | Bounded jobs/requests/events and common deadlines |

### IMPORTANT

| Problem | Why/risk | Location | Recommended fix |
|---|---|---|---|
| Context/evidence ignored | Cross-file defect recall suffers | `RoleReviewAgent.execute` | Build bounded context packets |
| Unbounded role prompts | Context errors, expensive retries, incomplete outputs | Planner grouping/specialist prompt | Token-aware task batches |
| Mutable/unverified artifacts | Resume and displayed source can differ | Snapshotter, `_read_artifact`, `resume_job`, frontend source resolver | Immutable artifacts and hash verification |
| Provenance/identity loss | Duplicate merging and verifier lookup lose observations | Models/deduplicator | Occurrence IDs and preserved support records |
| Retry multiplication | Quota, latency, repeated charges | LLM wrapper/resilience/SDK adapter | One explicit retry policy |
| Circuit probe lifecycle | Cancellation/nonretryable errors can block recovery | Circuit breaker/manager | Finally-based probe release and recovery tests |
| Ineffective shutdown tracking | Actual jobs not managed by server task set | Server/routes | Register real job/process handles |
| Post-call token accounting | Limits do not prevent spending; state leaks | Resilience manager | Reservations, durable accounting, cleanup |
| Python support mismatch | Declared supported runtime cannot import/run key paths | `pyproject.toml`, runner/manager | Require 3.11+ or implement compatibility |
| Storage retention mismatch | Artifacts expire while checkpoints persist | Snapshotter/storage/checkpointer | Coordinated retention |
| API/CLI/client contract drift | Different response/source/limit behavior | CLI, routers, frontend types | Shared explicit contracts |
| Legacy runtime ambiguity | More code paths than operationally justified | Facade/legacy agents/prompts | Deliberate consolidation |

### OPTIONAL

| Improvement | Benefit | Condition |
|---|---|---|
| Semantic retrieval | Better context discovery | Add only after deterministic retrieval evaluation |
| Semantic duplicate suggestions | Related-root-cause grouping | Preserve evidence and deterministic final decisions |
| Model diversity for verification | Reduce correlated errors | Demonstrate benefit against added cost |
| Distributed queue/storage | Multi-worker operations | Introduce when deployment/load requires it |
| Narrative summary agent | Better executive prose | Accepted findings remain immutable |
| Advanced profiling agents | Runtime performance evidence | Only with safe execution and demonstrated need |

## 27. Recommended Architecture

Preserve the finite workflow and deterministic final report. Repair the contracts around it.

1. **One job boundary:** authenticate, authorize workspace, validate payload, reserve capacity, set deadline, assign correlated IDs.
2. **Coverage-first preparation:** collect requested changes before review limits; record supported, skipped, and failed targets.
3. **Immutable source capture:** snapshot once, verify content identity, use the same source for review, resume, and UI.
4. **Safe evidence collection:** deterministic static tools; optional isolated command worker.
5. **Deterministic baseline routing:** every supported executable target receives correctness coverage. Optional LLM routing adds focused roles.
6. **Bounded tasks:** split by source/token budget and include relevant diff, callers, tests, and tool evidence.
7. **Parallel specialists:** independent tasks with typed outcomes and idempotent result reduction.
8. **Evidence-preserving deduplication:** retain all contributing agent/task observations.
9. **Bounded verification:** verify independent candidate batches concurrently; require one explicit disposition per candidate.
10. **Deterministic gate:** validate snapshot/path/range, evidence, decision completeness, and policy.
11. **Truthful report:** accepted findings, unresolved candidates, coverage, skips, failures, cost, and outcome.
12. **Operational persistence:** coordinated checkpoints/artifacts/reports, cancellation, retention, and trace correlation.

A better state would contain:

- Immutable `ReviewJob` and `ArtifactManifest` references.
- `CoverageRecord[]`.
- `ReviewTask[]` and typed `TaskOutcome` records.
- Candidate observations keyed by emission ID.
- Canonical findings preserving supporting observations.
- Verification decisions keyed by candidate ID.
- Typed failure/disposition records.
- Budget/deadline state.
- Final report ID/outcome.

This is an evolution of the current architecture, not a recommendation for a new supervisor hierarchy.

## 28. Recommended Architecture Diagram

```mermaid
flowchart TD
    Input["CLI / REST / browser WS"] --> Admission["Authentication + authorization + limits"]
    Admission --> Job["Job ID + deadline + capacity reservation"]
    Job --> Scope["Change discovery + explicit coverage manifest"]
    Scope --> Snapshot["Immutable source snapshot"]

    Snapshot --> Static["Deterministic static diagnostics"]
    Snapshot --> Sandbox["Optional isolated execution worker"]
    Sandbox --> Evidence["Sanitized typed tool evidence"]
    Static --> Evidence

    Evidence --> Route["Deterministic baseline + optional LLM routing"]
    Route --> Packets["Token-bounded tasks with diff and dependency context"]

    Packets --> Specialists["Parallel conditional specialists"]
    Specialists --> Outcomes["Typed outcomes + idempotent reducers"]
    Static --> Outcomes

    Outcomes --> Dedup["Evidence-preserving deduplication"]
    Dedup --> Verify["Bounded parallel verification"]
    Verify --> Decisions["Explicit disposition for every candidate"]
    Decisions --> Gate["Deterministic evidence and policy gate"]

    Gate --> Report["Truthful report: findings + coverage + failures"]
    Report --> Delivery["Persist + stream / return"]

    Job -.-> Persistence["Versioned checkpoints and coordinated retention"]
    Snapshot -.-> Persistence
    Outcomes -.-> Persistence
    Report -.-> Persistence

    Admission -.-> Trace["Redacted correlated LangSmith traces"]
    Evidence -.-> Trace
    Specialists -.-> Trace
    Verify -.-> Trace
    Report -.-> Trace
```

Every added boundary addresses an observed current problem. No additional specialist role is required.

## 29. Before vs After Comparison

| Area | Current | Recommended |
|---|---|---|
| Coverage | Implicit and limited before change selection | Explicit requested/reviewed/skipped manifest |
| Routing | Model plan or filename fallback | Mandatory deterministic baseline; optional refinement |
| Task size | One merged task per role | Token-bounded role/file/symbol batches |
| Context | Selected but ignored | Relevant diff/caller/test/evidence packet |
| Commands | Host processes | Disabled or isolated worker |
| Candidates | Accepted defaults and loose evidence | Unverified typed observations |
| Static findings | Title-based conclusive bypass | Rule-specific evidence/proof policy |
| Verification | Serial files; permissive defaults | Bounded parallel decisions with complete reconciliation |
| Deduplication | Loses support/provenance | Preserves all contributing evidence |
| State reducers | Deterministic concatenation/top cap | Pure idempotent reduction |
| Resume | Existing artifact path trusted | Hash/version/retention checks |
| Authentication | Transport-specific owner strings | Stable principal |
| Cancellation | Coroutine-oriented | Job and process lifecycle |
| Reporting | Counts and partial failures | Coverage, dispositions, outcome, cost |
| Tracing | Graph/model traces | End-to-end correlated, redacted stage traces |
| Evaluation | Binary clean/buggy normalization | Finding quality plus operational correctness |

## 30. Architecture Scorecard

These scores reflect the inspected source and available historical evidence.

| Dimension | Score | Reason |
|---|---:|---|
| Agent specialization | 5/10 | Meaningful roles, mostly prompt-level specialization |
| Orchestration | 6/10 | Finite, understandable workflow; weak coverage guarantees |
| State design | 6/10 | Correct parallel reducers; mutable/duplicated data and weak outcomes |
| Tool design | 4/10 | Useful helpers, unsafe host execution, evidence not consumed |
| Prompt design | 4/10 | Clear roles, missing context/schema/calibration |
| Structured outputs | 5/10 | Pydantic present; permissive defaults and post-generation parsing |
| Error handling | 4/10 | Partial branches work; silent-empty behavior remains |
| Retry design | 4/10 | Bounded but nested and inefficient |
| Observability | 6/10 | LangSmith/model tracing exists; preparation/correlation gaps |
| Evaluation readiness | 5/10 | Runnable adapter and fixtures; misleading clean semantics |
| Security | 3/10 | Untrusted-code execution and access/data boundaries incomplete |
| Scalability | 3/10 | Silent discovery caps, large prompts, serial verification |
| Latency efficiency | 4/10 | Parallel specialists help; verification/client setup dominate |
| Cost efficiency | 4/10 | Conditional roles help; duplication/retries/budget defects |
| Maintainability | 5/10 | Useful separation, oversized engine and legacy duplication |
| Testability | 7/10 | Injection and many tests; integration/quality gaps |
| Production readiness | 3/10 | Multiple operational and correctness blockers |

## 31. Final Verdict

| Question | Verdict | Explanation |
|---|---|---|
| Is the overall architecture correct? | **PARTIALLY** | The workflow is reasonable, but evidence and outcome contracts are incomplete. |
| Is multi-agent justified? | **PARTIALLY** | Plausible specialization; no demonstrated advantage over simpler baselines. |
| Are individual agents correctly designed? | **PARTIALLY** | Roles are clear, but context, tools, schema strictness, and failure behavior need work. |
| Is the orchestrator correctly designed? | **PARTIALLY** | Correct finite dispatch, insufficient coverage and job lifecycle guarantees. |
| Is the LangGraph structure correct? | **YES** | The active graph is finite and uses conditional `Send` fan-out with reducers appropriately. |
| Is state management safe? | **PARTIALLY** | Parallel channels are appropriate; mutation, identity, replay, and persistence risks remain. |
| Is parallelism used correctly? | **PARTIALLY** | Specialists are correctly parallel; task size and serial verification limit effectiveness. |
| Are tools used correctly? | **PARTIALLY** | Deterministic helpers are useful; execution safety and evidence integration are deficient. |
| Is final aggregation correct? | **PARTIALLY** | Deterministic rendering and verifier restrictions are sound; valid findings can be lost. |
| Is the system production ready? | **NO** | Execution isolation, truthful coverage/outcomes, authentication, and lifecycle controls must be fixed. |

The current system is a useful development-stage review workflow. Its graph does not need a wholesale redesign. Its reliability depends on fixing what reaches the agents, what counts as verified evidence, and what the final report claims was reviewed.

## 32. Prioritized Improvement Roadmap

| Priority | Task | Reason | Affected components | Expected impact | Complexity |
|---|---|---|---|---|---|
| P0 | Disable host repository commands until isolated execution exists | Untrusted repository execution | Config, runner, engine | Removes host-execution exposure | Low to disable; High to isolate |
| P0 | Introduce explicit review/task outcomes | Empty output must not mean successful clean review | Agents, models, engine, reporting, evaluation | Prevents misleading clean results | Medium |
| P0 | Select changed files before caps and record skips | Current ordering loses targets | Scanner, evidence collector, engine | Restores truthful coverage | Medium |
| P0 | Repair static verification semantics | Nonconclusive candidates permanently fail; heuristics auto-pass | Static analyzer, verify, gate | Improves precision and recall | Medium |
| P0 | Require complete explicit verifier decisions | Acceptance defaults are unsafe | Models, verifier, engine | Prevents implicit authorization of findings | Medium |
| P0 | Unify REST/WS identity and browser authentication | Production flow and ownership broken | Auth, routers, frontend API | Makes authenticated use functional | Medium |
| P0 | Apply request/job/queue/deadline limits consistently | Current operational bounds incomplete | Operations, facade, WS, server | Limits resource exhaustion and runaway jobs | Medium |
| P0 | Correct supported Python version | Declared runtime incompatible | Packaging/CI/docs | Prevents unsupported startup failures | Low |
| P1 | Include selected context, changed regions, and evidence in prompts | Prepared evidence currently unused | Agents, context selector, task model | Better cross-file review quality | Medium |
| P1 | Implement token-bounded task packets | Whole-role prompts do not scale | Planner normalization, context preparation | Predictable context and work units | High |
| P1 | Preserve provenance and distinguish finding occurrences | Dedup/verification identity loss | Models, deduplicator, reducers | Better recall and auditability | Medium |
| P1 | Make artifacts immutable and validate hashes on resume | Review source can drift | Snapshotter, engine, frontend source | Reproducible reviews | Medium |
| P1 | Consolidate active/legacy contracts | Maintenance ambiguity | Facade, agents, prompts, strategies | Fewer conflicting code paths | Medium |
| P2 | Consolidate retry ownership | Nested attempts inflate cost/latency | Adapter, LLM wrapper, resilience | Predictable retry behavior | Medium |
| P2 | Fix circuit probe cleanup and job usage lifecycle | Recovery/accounting defects | Circuit breaker, resilience manager | Better outage recovery | Medium |
| P2 | Implement actual server job/process tracking | Shutdown tracking ineffective | Server, operations, WS | Reliable cancellation/shutdown | Medium |
| P2 | Add suppression dispositions and stage-level evaluations | Current misses cannot be diagnosed precisely | Engine, metrics, evaluation | Explains quality regressions | Medium |
| P2 | Add redacted trace correlation and preparation spans | Current traces incomplete | Engine, runner, providers, logs | Better production diagnosis | Medium |
| P2 | Coordinate checkpoint/artifact/report retention | Resume and sensitive-data lifecycle | Persistence/storage | Predictable retention | Medium |
| P3 | Parallelize independent verification batches | Serial verifier dominates latency | Graph/verification | Reduced review latency | Medium |
| P3 | Reuse and close provider clients | Per-call client churn | Provider adapter | Lower overhead/resource leakage | Low–Medium |
| P3 | Remove repeated AST scans and optimize deduplication | Duplicate work | Engine, deduplicator | Lower preparation/aggregation cost | Low–Medium |
| P3 | Add preflight token reservations and model capability checks | Post-call accounting is not a hard budget | Providers, resilience, task builder | More predictable cost | Medium |
| P3 | Benchmark smaller routing models and targeted caching | Optimize after quality is stable | Planner, provider config, cache | Lower cost without blind quality tradeoffs | Medium |
| P4 | Add semantic retrieval if measured necessary | Larger context discovery | Retrieval layer | Better large-repository context | High |
| P4 | Add distributed job/storage infrastructure when required | Multi-worker deployment | Queue, persistence, rate limiting | Operational scaling | High |
| P4 | Evaluate model diversity or optional summaries | Potential quality/presentation benefit | Verifier/summarizer | Benefit must exceed cost | Medium |

**Acceptance gates before production:** untrusted execution is isolated or disabled; every requested target has a coverage disposition; failures cannot be classified clean; every reported issue has an explicit valid verification path; production browser authentication and cross-transport report retrieval work; cancellation terminates job work; and realistic evaluations demonstrate acceptable finding-level precision and recall.

No application code was changed for this audit. Runtime tests, builds, browser flows, and live LangSmith traces remain unverified.
