"""Run the production DevWatch review workflow against the LangSmith dataset."""

import asyncio
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from langsmith import aevaluate

from devwatch.models import CodeIssue, ReviewReport
from devwatch.review.factory import create_review_engine


DATASET_NAME = "langsmith_multi_agent_code_review_dataset"
EXPERIMENT_PREFIX = "code-review-v1"
EVALUATION_STATE_DIR = Path(".devwatch") / "langsmith-evaluation"

_LANGUAGE_EXTENSIONS = {
    "javascript": ".js",
    "js": ".js",
    "python": ".py",
    "py": ".py",
}


def _dataset_source(inputs: Mapping[str, Any]) -> tuple[str, str, str]:
    for field in ("code", "language"):
        if field not in inputs:
            raise ValueError(f"missing required dataset field: {field}")

    code = inputs["code"]
    language = inputs["language"]
    if not isinstance(code, str):
        raise TypeError("code must be a string")
    if not isinstance(language, str) or not language.strip():
        raise TypeError("language must be a non-empty string")

    normalized_language = language.strip().lower()
    extension = _LANGUAGE_EXTENSIONS.get(normalized_language)
    if extension is None:
        supported = ", ".join(sorted(_LANGUAGE_EXTENSIONS))
        raise ValueError(
            f"unsupported language {language!r}; supported values: {supported}"
        )
    return f"evaluation_input{extension}", code, normalized_language


def _normalize_issue(issue: CodeIssue) -> dict[str, Any]:
    start_line = issue.start_line or issue.line_number
    end_line = issue.end_line or issue.line_number or start_line
    return {
        "category": issue.category.strip().lower(),
        "description": issue.description,
        "severity": issue.severity.value.lower(),
        "title": issue.title,
        "recommendation": issue.suggestion,
        "file_path": issue.file_path,
        "start_line": start_line,
        "end_line": end_line,
    }


def _normalize_report(report: ReviewReport) -> dict[str, Any]:
    issues = [_normalize_issue(issue) for issue in report.issues]
    manual_candidates = [
        _normalize_issue(issue) for issue in report.manual_review_candidates
    ]
    return {
        "clean": not issues and not manual_candidates,
        "issues": issues,
        "manual_review_candidates": manual_candidates,
        "summary": report.summary,
        "metrics": report.metrics,
    }


async def review_target(inputs: dict[str, Any]) -> dict[str, Any]:
    """Adapt one LangSmith example to the production async review entry point."""
    if not isinstance(inputs, Mapping):
        raise TypeError("dataset input must be a mapping")
    file_path, code, language = _dataset_source(inputs)

    try:
        engine = create_review_engine(
            runs_dir=EVALUATION_STATE_DIR / "runs",
            checkpoint_path=EVALUATION_STATE_DIR / "checkpoints.sqlite",
        )
        report = await engine.review_file(file_path, code)
    except Exception as error:
        raise RuntimeError(f"DevWatch review failed for {language}: {error}") from error

    return _normalize_report(report)


async def run_experiment():
    """Execute the existing dataset with its LangSmith-configured evaluator."""
    # Async target contract: https://reference.langchain.com/python/langsmith/client/Client/aevaluate
    return await aevaluate(
        review_target,
        data=DATASET_NAME,
        experiment_prefix=EXPERIMENT_PREFIX,
        description="DevWatch production multi-agent code review workflow",
        max_concurrency=1,
        error_handling="log",
    )


def main() -> None:
    asyncio.run(run_experiment())


if __name__ == "__main__":
    main()
