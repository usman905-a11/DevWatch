# DevWatch

DevWatch reviews changed code through durable jobs and produces evidence-based reports. Reviewed source stays read-only. The canonical service runs deterministic analysis, selected iterative specialists and a combined Synthesizer / Verifier before completion assessment, acceptance and deterministic rendering.

## Canonical seven-agent service

The new job service runs the agreed Planner, five iterative specialists and combined Synthesizer / Verifier through LangGraph. Completion Assessment finishes the review before acceptance and deterministic JSON/Markdown/PDF rendering. Its Balanced defaults are 600 seconds, 250k tokens/job, 50k/specialist, three concurrent model calls, eight iterations and twelve tools/task, one follow-up round, two safe transient retries and one schema repair.

Set all three model tiers to model identifiers supported by your provider, then start the service:

```powershell
$env:DEVWATCH_MODEL_SMALL = "your-small-model-id"
$env:DEVWATCH_MODEL_MEDIUM = "your-medium-model-id"
$env:DEVWATCH_MODEL_STRONG = "your-strong-model-id"
$env:DEVWATCH_PROVIDER = "openai"
$env:OPENAI_API_KEY = "replace-with-your-provider-key"
$env:DEVWATCH_API_KEY = "replace-with-your-private-service-key"
uvicorn devwatch.review.service:create_app --factory --host 127.0.0.1 --port 8000
```

For Gemini's compatible endpoint, set `DEVWATCH_PROVIDER=gemini` and `GEMINI_API_KEY`; the same existing adapter also accepts an OpenRouter key. These examples contain placeholders, not recommended model IDs. Production (`DEVWATCH_ENV=production`) requires the service key; development without a key permits loopback clients only. Automatic source/prompt tracing is disabled.

Use `X-API-Key` or a Bearer header consistently. Capture source with `POST /api/snapshots` (`{"files":{"service.py":"..."}}`), then submit `POST /api/jobs` (`{"snapshot_id":"...","changed_files":["service.py"]}`) with an `Idempotency-Key` header. Omitting `changed_files` reviews the snapshot scope. Reuse the same snapshot and key to retry submission safely.

- Poll `GET /api/jobs/{job_id}`; explicitly cancel or resume with `POST .../cancel` or `POST .../resume`.
- Retrieve a finalized report with `GET .../report?format=json`, `format=markdown` or `format=pdf`. PDF downloads are owned, hash-checked Artifact Store files, generated only after acceptance.
- Retrieve the owned immutable file catalog with `GET .../snapshot` to reopen source navigation for an existing job.
- Read bounded immutable source with `GET .../source?file_path=service.py&start_line=1&end_line=20`; retrieve tool evidence with `GET .../evidence/{evidence_ref}`.
- Replay persisted events with `GET .../events?after=0&limit=100`; stream SSE at `.../stream` using `Last-Event-ID`, or WebSocket at `.../ws?after=0`. Browser WebSockets authenticate with the first JSON message `{"api_key":"..."}`. Credentials never belong in URLs. Stream disconnect does not cancel the review.

The default runtime directory `.devwatch/runtime/` separates `jobs.sqlite`, `checkpoints.sqlite`, `repo-cache.sqlite`, `events.sqlite` and `artifacts/`. Graceful shutdown interrupts active jobs for explicit resume. On startup and during service operation, abandoned running jobs become interrupted after the worker's process lock is released; queued jobs restart automatically. Resume preserves checkpoints, original intent and cumulative budgets. Outstanding model reservations and uncertain crash time are charged conservatively; a long outage can exhaust the review and produce a partial deadline report. A live worker is never displaced merely because its heartbeat is old. Run this SQLite service on a local filesystem; network/distributed storage needs the later adapters. Failed mandatory agents and expired deadlines yield explicit partial coverage and unverified candidates. JS/TS parsers and trusted execution/profiling adapters remain implementation work; absent tools are reported as unavailable.

The verified reproducible environment is Windows x64 with Python 3.11. To install its complete runtime/test/build closure with wheel hashes:

```powershell
python -m venv .venv-verified
.venv-verified/Scripts/python.exe -m pip install --require-hashes -r requirements-windows-py311.lock
.venv-verified/Scripts/python.exe -m pip install --no-build-isolation --no-deps -e .
.venv-verified/Scripts/python.exe -m pip check
```

The lock is platform-specific; the existing dependency ranges and `constraints.txt` remain available for other environments. Other OS/Python combinations need their own installation/regression gate. These pins reproduce verified behavior and are not a vulnerability audit. See [the recovery decision](docs/decisions/001-local-job-recovery.md).

## Canonical CLI

The CLI now uses the same durable job API. Install with `python -m pip install -e .`, configure the service above, and run:

```powershell
devwatch serve
# In a second terminal with the same DEVWATCH_API_KEY:
devwatch review . --output report.md
devwatch review . --no-wait
devwatch job JOB_ID
devwatch job JOB_ID --report --format json --output report.json
devwatch job JOB_ID --report --format pdf --output report.pdf
devwatch resume JOB_ID
devwatch cancel JOB_ID
devwatch watch . --interval 1 --debounce 1
devwatch watch . --max-reviews 3
```

Use `DEVWATCH_SERVICE_URL` or `--service-url` to select the service. Closing the CLI, interrupting its wait, or a client timeout does not cancel a submitted job. Report outputs require new `.md`/`.json` files; existing files are never overwritten. The report comes from the service's deterministic renderer.

Capture includes eligible nearby source, selects staged/unstaged/untracked Git status paths, and records skipped or unreadable files. Single-file and non-Git requests select all captured source. A clean Git scope makes no model calls and reports that source was not inspected. Capture omissions are client-reported metadata, separately hashed in the immutable manifest; they never count as inspection evidence. Capture preserves source bytes and rejects sensitive filenames, generated files and links. Directory enumeration charges every entry against its 10,000-entry limit, has a ten-second catalog deadline and records unreadable directories. Git filters and filesystem-monitor commands are disabled during capture. Submodules are not traversed and are reported as skipped; review each selected submodule separately. Diff hunks, history and deleted source are not uploaded.

Before submission, `review` prints the snapshot ID, exact changed-file list and idempotency key. If submission has an unknown outcome, reuse those values with `devwatch submit SNAPSHOT_ID --idempotency-key KEY --changed-file PATH` (repeat `--changed-file` for every original path, in the same order). For an originally empty list, use `--empty-scope`. Omitting scope selects the entire snapshot and must not replace an original explicit list. Reusing the exact request returns the same job; changed requests are rejected. Do not recapture source to retry an existing intent.

`watch` uses the same bounded, read-only capture and owned job APIs. It initially submits eligible current scope after the debounce window, then observes source hashes, selected paths and capture coverage. Clean Git scope does not submit a review unless deletions or capture failures need an explicit coverage report. Edits while a job runs are coalesced into one latest pending capture; unchanged versions are not automatically retried. Directory deletions remain explicit omissions, with a 1000-path history cap. Generated/sensitive file contents are excluded. Polling can miss transient edits between scans, and deleting the selected root/file stops capture; watch its containing directory to observe deletion/recreation.

Each watch submission prints its exact recovery intent and job ID. `--max-reviews` limits submissions and exits without waiting for the last job; otherwise Ctrl+C stops only the watcher. An unknown POST result or interrupted job stops watch for explicit recovery/resume/cancel, never automatic recapture or retry. Inspect completed reports with `devwatch job JOB_ID --report` or open the job in the web UI. Watch has no local model, source-writing or report-publishing engine.

The CLI and frontend now consume the canonical service. The legacy backend below awaits its remaining migration gates. Follow [the implementation checklist](tasks/todo.md) and [migration inventory](tasks/migration-inventory.md); remaining legacy removal follows successful cutover and regression checks.

## Existing clients awaiting migration

From the repository root:

```powershell
python -m pip install -e .
$env:GEMINI_API_KEY = "replace-with-your-key"
$env:DEVWATCH_RUN_COMMANDS = "false"
uvicorn devwatch.server:app --port 8000
```

The legacy server uses its existing model defaults and environment settings until cutover. `DEVWATCH_WORKSPACE_DIR` limits which local paths that server can read. These settings do not override the canonical service's explicit model tiers or Balanced policy.

For a frontend development session, start the **canonical seven-agent service** above, then run `npm install` and `npm run dev` in `frontend/`. The app defaults to `http://localhost:8000`; open **Service connection** to set its address and API key. Credentials stay in memory, not browser storage. The legacy server below does not support this migrated frontend.

Choose **Open local folder** to capture eligible UTF-8 source, then **Run review**. Browser capture admits at most 100 files, 500 KB per file and 10 MB total, records omissions, and reviews whole uploaded files without Git history. For Git scope, start `devwatch review PATH --no-wait` and enter its job ID using **Open job**. Copy the job ID to reopen the review after closing/reloading the browser. **Reconnect** only reads the existing job; **Resume review** and **Cancel review** are explicit controls. An unknown submission retains its original snapshot/key for **Retry same submission**.

Reports keep confirmed defects, uncertain high-impact candidates and advisories separate, with inspected/skipped/failed coverage and limitations. Source navigation reads immutable job snapshots in bounded excerpts; it never reads the live server filesystem. JSON/Markdown/PDF downloads are deterministic. PDFs use a bundled font; unsupported glyphs and invisible controls are shown as Unicode escapes. The CLI requires a new `.pdf` output file for binary exports. Jobs finalized before PDF support return an explicit unavailable response for that format. Watch-created job IDs can be opened in this same view.

## Review interfaces

- REST: `POST /api/review` with `{"target_path":"."}`; `POST /api/review/file` and `POST /api/review/files` accept uploaded source; `GET /api/reports/{report_id}` retrieves stored repository reports.
- WebSocket: `/ws/review` accepts `{"target_path":"."}`, sends `agent_update` frames and a final `review_completion` with `report_id`, or `review_error`. A disconnected client cancels its review.
- Retired mutation endpoints (`/api/review/propose-fix`, `/api/review/apply-proposal`, `/api/review/apply-fix`, and `/api/fs/write`) remain discoverable and return HTTP 410. They do not change files.

Repository reviews use staged, unstaged, and untracked Git changes. For a non-Git directory, DevWatch reviews its eligible files. A clean Git tree produces an explanatory empty report. The strict gate requires source evidence and verification before a finding is confirmed. Uncertain high-impact findings appear separately for manual review. If a stage fails, the report records the failure and may be partial.

## Limits and command containment

The main settings are listed in [`.env.example`](.env.example). Defaults in `devwatch/config.py` include 100 review files, 1,000 snapshot files, 10 MB of scanner input, 100 MB per snapshot, 1,000 candidate findings, 10 concurrent LLM calls, 250,000 job tokens, and a 120-second review deadline. The command runner caps each command at 120 seconds and 200,000 captured output bytes; `DEVWATCH_RUN_COMMANDS=false` disables commands.

When commands are enabled, DevWatch discovers supported test commands or reads exact argv entries from `.devwatch.toml`. It rejects shells, inline Python, package installation, path traversal, and executables inside the reviewed workspace. Commands run with secret-like environment variables removed and within a disposable source snapshot. This is containment for accidental effects, not a security boundary for hostile code. Disable commands when reviewing untrusted repositories.

## Generated data and retention

| Data | Default location | Lifecycle |
|---|---|---|
| Source snapshots and uploaded-file artifacts | `.devwatch/runs/{job_id}/` | The engine prunes expired run directories when a new engine starts; default retention is 7 days (`DEVWATCH_ARTIFACT_RETENTION_DAYS`). A resume requires its run directory to remain. |
| LangGraph checkpoints | `.devwatch/checkpoints.sqlite` | Durable across restarts. No automatic row pruning occurs. Stop reviews before deleting the database and its SQLite sidecar files; doing so removes all resume state. |
| Stored REST/WebSocket repository reports | `.devwatch/reports/{report_id}.json` | Persist until an operator removes them. Report lookup stops working after deletion. |

Keep `.devwatch/` private: artifacts and reports can contain source code, and checkpoints contain review metadata. Back up or purge these locations under your own retention policy. Never remove an active run directory or SQLite database during a review.

## Verification

```powershell
python -m pytest -q
python -m scripts.export_review_contracts --check
python -m pytest tests/test_m5_acceptance.py -q -s
cd frontend
npm test
npm run build
```

The versioned offline evaluation uses 20 changed-file cases and scores confirmed findings from a real Git-change review without a live provider. It measures the deterministic path; live-model accuracy depends on the configured provider and is not established by that offline gate.
