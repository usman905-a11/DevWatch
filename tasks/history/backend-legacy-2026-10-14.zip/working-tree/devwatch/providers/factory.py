import os
from typing import Optional
from devwatch.config import Config, ModelTier
from devwatch.providers.base import LLMProvider
from devwatch.providers.openai_adapter import OpenAIProviderAdapter
from devwatch.providers.fake_provider import FakeLLMProvider

_active_provider: Optional[LLMProvider] = None


def get_provider() -> LLMProvider:
    """Return configured active LLM provider singleton or instance."""
    global _active_provider
    if _active_provider is not None:
        return _active_provider

    model = os.getenv("LLM_MODEL") or Config.get_model_for_tier(ModelTier.HEAVY)
    if model.startswith("gemini-"):
        provider_name = "gemini"
    elif os.getenv("OPENROUTER_API_KEY"):
        provider_name = "openrouter"
    else:
        provider_name = "openai"
    _active_provider = OpenAIProviderAdapter(provider_name=provider_name)
    return _active_provider


def set_provider(provider: Optional[LLMProvider]) -> None:
    """Override default LLM provider (e.g. for testing with FakeLLMProvider)."""
    global _active_provider
    _active_provider = provider


def reset_provider() -> None:
    """Reset active LLM provider to default."""
    global _active_provider
    _active_provider = None
