"""Shared report persistence for HTTP and WebSocket transports."""

import time
from typing import List

from devwatch.models import AgentStepUpdate, ReviewReport
from devwatch.storage import ReportStorage


report_storage = ReportStorage()


def create_report_record(
    report_id: str, report: ReviewReport, target_path: str,
    owner: str, steps: List[AgentStepUpdate],
) -> dict:
    report_dict = report.model_dump()
    report_dict.update(
        total_issues=report.total_issues,
        critical_count=report.critical_count,
        high_count=report.high_count,
        medium_count=report.medium_count,
        low_count=report.low_count,
    )
    return {
        "report_id": report_id,
        "owner": owner,
        "target_path": target_path,
        "status": "completed",
        "timestamp": time.time(),
        "steps": [step.model_dump() for step in steps],
        "report": report_dict,
        "summary_markdown": report.summary,
    }
