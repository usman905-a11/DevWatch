from pathlib import Path

from devwatch.config import Config
from devwatch.providers.factory import get_provider
from devwatch.review.agents import RiskPlannerAgent, RoleReviewAgent, StrictVerifierAgent
from devwatch.review.engine import ReviewEngine
from devwatch.review.models import SpecialistRole


def create_review_engine(
    *,
    runs_dir: str | Path | None = None,
    checkpoint_path: str | Path | None = None,
) -> ReviewEngine:
    provider = get_provider()
    return ReviewEngine(
        planner=RiskPlannerAgent(provider=provider),
        specialists={
            role: RoleReviewAgent(role, provider=provider) for role in SpecialistRole
        },
        verifier=StrictVerifierAgent(provider=provider),
        verification_threshold=Config.VERIFICATION_CONFIDENCE_THRESHOLD,
        runs_dir=Path(runs_dir) if runs_dir is not None else Path(Config.REVIEW_RUNS_DIR),
        run_commands=Config.REVIEW_COMMANDS_ENABLED,
        checkpoint_path=(
            Path(checkpoint_path)
            if checkpoint_path is not None
            else Path(Config.CHECKPOINT_DB_PATH)
        ),
    )
