# DevWatch architecture

DevWatch is a local-first, report-only code reviewer. It examines changed code, gathers evidence from source analysis and optional configured commands, asks specialized AI agents to review that evidence, verifies proposed findings, and produces a review report. It does not apply code fixes. Repository reviews focus on Git changes; uploaded files and directories without Git history are reviewed as supplied.

## Component map

```mermaid
flowchart LR
    subgraph Clients[Clients]
        UI["React UI<br/>file explorer, editor, agent panel"]
        CLI["Typer CLI<br/>devwatch review"]
    end

    subgraph API[FastAPI service]
        FS["Filesystem routes<br/>tree and read"]
        REST["Review REST routes<br/>path or uploaded files"]
        WS["Review WebSocket<br/>path and progress"]
        Guards["API key checks<br/>rate limits and audit log"]
        Ops["ReviewOperations<br/>validation and orchestration"]
        ReportStore["Report builder and JSON storage"]
    end

    subgraph Review[Review core]
        Facade["ReviewPipeline<br/>public facade and timeout"]
        Engine["ReviewEngine"]
        Inputs["Scanner, Git change collector<br/>and context selector"]
        Evidence["Workspace snapshot<br/>AST analyzer and command runner"]
        Graph["LangGraph review workflow"]
        Renderer["Deterministic report renderer"]
    end

    subgraph External[Models and local state]
        Provider["LLM provider adapter<br/>retry, circuit breaker, token budget"]
        Artifacts[(".devwatch/runs<br/>snapshot artifacts")]
        Checkpoints[(".devwatch/checkpoints.sqlite<br/>graph checkpoints")]
        Reports[(".devwatch/reports<br/>saved JSON reports")]
    end

    UI -->|"browse server files"| FS
    UI -->|"upload selected folder files"| REST
    UI -->|"review server path; receive updates"| WS
    CLI --> Facade
    Guards -.-> FS
    Guards -.-> REST
    Guards -.-> WS
    REST --> Ops
    WS --> Ops
    Ops --> Facade
    Facade --> Engine
    Engine --> Inputs
    Inputs --> Evidence
    Evidence --> Graph
    Evidence --> Artifacts
    Graph --> Provider
    Graph --> Checkpoints
    Graph --> Renderer
    Renderer --> Ops
    Renderer --> CLI
    REST -->|"repository reviews"| ReportStore
    WS -->|"repository reviews"| ReportStore
    ReportStore --> Reports
    Ops -.-> Guards
```

The browser's **Open folder** flow reads files in the browser and sends their contents to `POST /api/review/files`. That path has no Git metadata, so it reviews the uploaded files. A server-side path sent through the WebSocket, REST path endpoint, or CLI can use Git changes. The filesystem routes let the browser explore files the server can access; they do not write source files.

## End-to-end review flow

```mermaid
flowchart TD
    Request["Review request"] --> Kind{"Input"}
    Kind -->|"repository path"| Scan["Validate path and scan eligible files"]
    Kind -->|"uploaded file contents"| Upload["Use supplied files"]
    Scan --> Git{"Git repository?"}
    Git -->|"yes"| Diff["Collect staged, unstaged and untracked changes"]
    Git -->|"no"| All["Review eligible files"]
    Diff --> Changed{"Changed regions?"}
    Changed -->|"none"| Empty["Return explanatory empty report"]
    Changed -->|"some"| Context["Select changed regions and related context"]
    All --> Snapshot["Create review snapshot and artifacts"]
    Context --> Snapshot
    Upload --> Snapshot
    Snapshot --> Static["AST static analysis"]
    Snapshot -.->|"optional configured commands for repository reviews"| Commands["Run commands in disposable snapshot"]
    Static --> State["Typed review state with evidence and candidates"]
    Commands --> State
    State --> Plan["Risk planner selects review tasks"]
    Plan --> Specialists["Parallel specialist reviews<br/>security, architecture/API, correctness, performance"]
    Specialists --> Dedup["Merge and deduplicate candidate findings"]
    Dedup --> Verify["Strict verifier checks claims against evidence"]
    Verify --> Gate["Strict gate accepts supported findings<br/>and retains severe uncertain claims for manual review"]
    Gate --> Render["Render deterministic Markdown and ReviewReport"]
    Render --> Result["Return report and progress to caller"]
```

The planner, four specialist roles, and verifier use Gemini 3.7 Flash by default through a shared provider adapter. The planner can fall back to deterministic task selection when no model is available. Conclusive static findings can pass verification without a model call; other claims need the verifier. The LangGraph state is checkpointed in SQLite, while source snapshots and other large artifacts live under `.devwatch/runs`. A saved checkpoint can be used to resume a job.

## Entry points and outputs

| Entry point | Input | Feedback and result | Persistence |
| --- | --- | --- | --- |
| React Open folder | Browser-uploaded file contents through `POST /api/review/files` | Completed response with confirmed findings and manual candidates | No saved report record |
| REST `POST /api/review` | Server-side repository path | Completed response with collected step updates and report ID | JSON report under `.devwatch/reports` |
| WebSocket `/ws/review` | Server-side repository path | Live agent updates, then completion with report ID | JSON report under `.devwatch/reports` |
| CLI `devwatch review` | Local directory path | Terminal summary; optional Markdown output file | No API report record |

`GET /api/reports/{report_id}` retrieves saved API reports with an ownership check. Review requests pass API key and rate-limit checks; review operations record audit events. The CLI calls the review facade directly, so it does not pass through the HTTP API. The report is advisory: confirmed findings are kept separate from items that need manual review, and DevWatch does not modify the reviewed source.

## Main code locations

| Responsibility | Code |
| --- | --- |
| CLI entry point and configuration | `devwatch/cli.py`, `devwatch/config.py` |
| UI and request transport | `frontend/src/App.tsx`, `frontend/src/hooks/useCodeReview.ts`, `frontend/src/services/api.ts` |
| HTTP, WebSocket, and API guards | `devwatch/server.py`, `devwatch/routers/`, `devwatch/auth.py`, `devwatch/rate_limiter.py`, `devwatch/audit_log.py` |
| Request validation and orchestration | `devwatch/operations/review_operations.py`, `devwatch/pipeline/dag.py` |
| Review preparation and execution | `devwatch/scanner.py`, `devwatch/review/engine.py`, `devwatch/review/evidence.py`, `devwatch/review/runner.py`, `devwatch/tools/static_analyzer.py` |
| Graph state, agents, findings, and rendering | `devwatch/review/state.py`, `devwatch/review/agents.py`, `devwatch/models.py`, `devwatch/review/reporting.py` |
| Model access and report persistence | `devwatch/providers/`, `devwatch/agents/llm.py`, `devwatch/reports.py`, `devwatch/storage.py` |

The graph and artifact stores are local. Configured review commands run in a disposable workspace snapshot; that containment is not a security sandbox for hostile code.
